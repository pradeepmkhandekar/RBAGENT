package com.rupeeboss.rba.core.response;

import com.rupeeboss.rba.core.APIResponse;

/**
 * Created by IN-RB on 14-02-2017.
 */

public class NewRegistrationResponse extends APIResponse {

}
