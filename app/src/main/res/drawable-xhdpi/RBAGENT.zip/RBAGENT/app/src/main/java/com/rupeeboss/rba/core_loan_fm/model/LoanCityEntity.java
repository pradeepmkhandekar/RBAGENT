package com.rupeeboss.rba.core_loan_fm.model;

public  class LoanCityEntity {
            /**
             * cityId : 6
             * cityName : AGARTALA
             */

            private int cityId;
            private String cityName;

            public int getCityId() {
                return cityId;
            }

            public void setCityId(int cityId) {
                this.cityId = cityId;
            }

            public String getCityName() {
                return cityName;
            }

            public void setCityName(String cityName) {
                this.cityName = cityName;
            }
        }