package com.rupeeboss.rba.core_loan_fm.response;


import com.rupeeboss.rba.core_loan_fm.APIResponseERP;

/**
 * Created by Rajeev Ranjan on 19/09/2018.
 */

public class GenerateHLLeadResponse extends APIResponseERP {
}
