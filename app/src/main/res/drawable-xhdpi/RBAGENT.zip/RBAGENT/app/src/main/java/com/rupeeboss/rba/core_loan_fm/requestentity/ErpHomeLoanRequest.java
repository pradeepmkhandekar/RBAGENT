package com.rupeeboss.rba.core_loan_fm.requestentity;

/**
 * Created by IN-RB on 04-03-2018.
 */

public class ErpHomeLoanRequest {


    /**
     * ApplnId : 0
     * Level : null
     * Quote_id : 0
     * Residence_Type : null
     * Co_Residence_Type : null
     * empCode : null
     * Title : null
     * First_Name : null
     * Middle_Name : null
     * Last_Name : null
     * Marital_Status : null
     * Spouce_Name : null
     * Mother_Name : null
     * Category_Id : null
     * No_Of_Dependent : null
     * PAN_No : null
     * Passport_No : null
     * Driving_Lic_No : null
     * Aadhar_Card_No : null
     * Voters_Id : null
     * DOB : null
     * Status_Id : null
     * Gender : null
     * Nationality : null
     * Id_Type : null
     * Id_No : null
     * Institute_University : null
     * Mothers_Maidan_Name : null
     * Education_Id : null
     * Mobile_No1 : null
     * Mobile_No2 : null
     * Per_Email_Id : null
     * Ofc_Email_Id : null
     * Address1 : null
     * Address2 : null
     * Address3 : null
     * Landmark : null
     * Pincode : null
     * City : null
     * State : null
     * Country : null
     * LandlineNo : null
     * AddrsYrs : null
     * Per_Address1 : null
     * Per_Address2 : null
     * Per_Address3 : null
     * Per_Landmark : null
     * Per_Pincode : null
     * Per_City : null
     * Per_State : null
     * Per_Country : null
     * Per_LandlineNo : null
     * Per_AddrsYrs : null
     * Nature_Of_Employer : null
     * Nature_Of_Organization : null
     * Nature_Of_Business : null
     * Designation : null
     * Currnet_Employment_Period : null
     * Total_Employment_Period : null
     * Name_of_Organisation : null
     * Address1_of_Organisation : null
     * Address2_of_Organisation : null
     * Address3_of_Organisation : null
     * Organize_Landmark : null
     * Organize_Pincode : null
     * Organize_City : null
     * Organize_State : null
     * Organize_Country : null
     * Organize_LandlineNo : null
     * Gross_Income : null
     * Net_Income : null
     * Other_Income : null
     * Total_Income : null
     * IFSC_Code_Bank1 : null
     * Bank1_Name : null
     * Bank1_AcctType : null
     * Bank1_AcctNo : null
     * IFSC_Code_Bank2 : null
     * Bank2_Name : null
     * Bank2_AcctType : null
     * Bank2_AcctNo : null
     * Bank_Loan1 : null
     * Type_Loan1 : null
     * Amnt_Loan1 : null
     * EMI_Loan1 : null
     * Bank_Loan2 : null
     * Type_Loan2 : null
     * Amnt_Loan2 : null
     * EMI_Loan2 : null
     * Vehicle_Type : null
     * MakenModel_Vehicle : null
     * Dt_Purchase : null
     * Hypo_To : null
     * Vehicle_Type2 : null
     * MakenModel_Vehicle2 : null
     * Dt_Purchase2 : null
     * Hypo_To2 : null
     * Co_Title : null
     * Co_First_Name : null
     * Co_Middle_Name : null
     * Co_Last_Name : null
     * Co_Marital_Status : null
     * Co_Spouce_Name : null
     * Co_Mother_Name : null
     * Co_Category_Id : null
     * Co_No_Of_Dependent : null
     * Co_PAN_No : null
     * Co_Passport_No : null
     * Co_Driving_Lic_No : null
     * Co_Aadhar_Card_No : null
     * Co_Voters_Id : null
     * Co_DOB : null
     * Co_Status_Id : null
     * Co_Gender : null
     * Co_Nationality : null
     * Co_Id_Type : null
     * Co_Id_No : null
     * Co_Institute_University : null
     * Co_Mothers_Maidan_Name : null
     * Co_Education_Id : null
     * Co_Mobile_No1 : null
     * Co_Mobile_No2 : null
     * Co_Per_Email_Id : null
     * Co_Ofc_Email_Id : null
     * Co_Address1 : null
     * Co_Address2 : null
     * Co_Address3 : null
     * Co_Landmark : null
     * Co_Pincode : null
     * Co_City : null
     * Co_State : null
     * Co_Country : null
     * Co_LandlineNo : null
     * Co_AddrsYrs : null
     * Co_Per_Address1 : null
     * Co_Per_Address2 : null
     * Co_Per_Address3 : null
     * Co_Per_Landmark : null
     * Co_Per_Pincode : null
     * Co_Per_City : null
     * Co_Per_State : null
     * Co_Per_Country : null
     * Co_Per_LandlineNo : null
     * Co_Per_AddrsYrs : null
     * Co_Nature_Of_Employer : null
     * Co_Nature_Of_Organization : null
     * Co_Nature_Of_Business : null
     * Co_Designation : null
     * Co_Currnet_Employment_Period : null
     * Co_Total_Employment_Period : null
     * Co_Name_of_Organisation : null
     * Co_Address1_of_Organisation : null
     * Co_Address2_of_Organisation : null
     * Co_Address3_of_Organisation : null
     * Co_Organize_Landmark : null
     * Co_Organize_Pincode : null
     * Co_Organize_City : null
     * Co_Organize_State : null
     * Co_Organize_Country : null
     * Co_Organize_LandlineNo : null
     * Co_Gross_Income : null
     * Co_Net_Income : null
     * Co_Other_Income : null
     * Co_Total_Income : null
     * Co_IFSC_Code_Bank1 : null
     * Co_Bank1_Name : null
     * Co_Bank1_AcctType : null
     * Co_Bank1_AcctNo : null
     * Co_IFSC_Code_Bank2 : null
     * Co_Bank2_Name : null
     * Co_Bank2_AcctType : null
     * Co_Bank2_AcctNo : null
     * Co_Bank_Loan1 : null
     * Co_Type_Loan1 : null
     * Co_Amnt_Loan1 : null
     * Co_EMI_Loan1 : null
     * Co_Bank_Loan2 : null
     * Co_Type_Loan2 : null
     * Co_Amnt_Loan2 : null
     * Co_EMI_Loan2 : null
     * Co_Vehicle_Type : null
     * Co_MakenModel_Vehicle : null
     * Co_Dt_Purchase : null
     * Co_Hypo_To : null
     * Co_Vehicle_Type2 : null
     * Co_MakenModel_Vehicle2 : null
     * Co_Dt_Purchase2 : null
     * Co_Hypo_To2 : null
     * Prop_Loan_Amount : null
     * Prop_Terms : null
     * Purpose_Of_Loan : null
     * Repayment_Mode : null
     * Prop_Id_Type : null
     * Prop_Processing_Fee : null
     * Cheque_No : null
     * Cheque_Date : null
     * Drawn_On : null
     * Loan_Cost : null
     * Purchase_Price : null
     * Amenities : null
     * Other_Cost : null
     * Own_contri_Paid : null
     * Own_contri_Payable : null
     * Personal_Loan_Other : null
     * Loan_Requested : null
     * Trans_type : null
     * Construction_stage : null
     * expected_Completion : null
     * Land_area : null
     * Built_up_area : null
     * Prop_Ownership_Name : null
     * Prop_type : null
     * Prop_Age : null
     * Prop_Use : null
     * Expect_Month_rent : null
     * Prop_Address1 : null
     * Prop_Address2 : null
     * Prop_Address3 : null
     * Prop_Landmark : null
     * Prop_Pincode : null
     * Prop_City : null
     * Prop_State : null
     * Prop_County : null
     * Msc_Ref1_Name : null
     * Msc_Ref1_Pin_code : null
     * Msc_Ref1_Landline_No : null
     * Msc_Ref1_Mob_No : null
     * Msc_Ref2_Name : null
     * Msc_Ref2_Pin_code : null
     * Msc_Ref2_Landline_No : null
     * Msc_Ref2_Mob_No : null
     * id : null
     * Datetime_Created : null
     * Ip_Address : null
     * UserId : null
     * LandlineNo_StdCode : null
     * Per_LandlineNo_StdCode : null
     * Organize_LandlineNo_StdCode : null
     * Co_LandlineNo_StdCode : null
     * Co_Per_LandlineNo_StdCode : null
     * Co_Organize_LandlineNo_StdCode : null
     * Msc_Ref1_LandlineNo_StdCode : null
     * Msc_Ref2_LandlineNo_StdCode : null
     * BankId : 0
     * BrokerId : 0
     * Is_ApplnComplete : 0
     * ProductId : 0
     * Is_Confirm : 0
     * IsCoApp : 0
     * Turn_Over : null
     * Depreciation : null
     * Director_Remuneration : null
     * Profit_Aft_Tax : null
     * Co_Turn_Over : null
     * Co_Depreciation : null
     * Co_Director_Remuneration : null
     * Co_Profit_Aft_Tax : null
     * FBA_Reg_Id : null
     * Appln_Source : null
     * sourcelink : null
     * CampaignName : null
     * dc_fba_reg : null
     * RBA_Source : null
     */

    private int ApplnId;
    private String Level;
    private int Quote_id;
    private String Residence_Type;
    private String Co_Residence_Type;
    private String empCode;
    private String Title;
    private String First_Name;
    private String Middle_Name;
    private String Last_Name;
    private String Marital_Status;
    private String Spouce_Name;
    private String Mother_Name;
    private String Category_Id;
    private String No_Of_Dependent;
    private String PAN_No;
    private String Passport_No;
    private String Driving_Lic_No;
    private String Aadhar_Card_No;
    private String Voters_Id;
    private String DOB;
    private String Status_Id;
    private String Gender;
    private String Nationality;
    private String Id_Type;
    private String Id_No;
    private String Institute_University;
    private String Mothers_Maidan_Name;
    private String Education_Id;
    private String Mobile_No1;
    private String Mobile_No2;
    private String Per_Email_Id;
    private String Ofc_Email_Id;
    private String Address1;
    private String Address2;
    private String Address3;
    private String Landmark;
    private String Pincode;
    private String City;
    private String State;
    private String Country;
    private String LandlineNo;
    private String AddrsYrs;
    private String Per_Address1;
    private String Per_Address2;
    private String Per_Address3;
    private String Per_Landmark;
    private String Per_Pincode;
    private String Per_City;
    private String Per_State;
    private String Per_Country;
    private String Per_LandlineNo;
    private String Per_AddrsYrs;
    private String Nature_Of_Employer;
    private String Nature_Of_Organization;
    private String Nature_Of_Business;
    private String Designation;
    private String Currnet_Employment_Period;
    private String Total_Employment_Period;
    private String Name_of_Organisation;
    private String Address1_of_Organisation;
    private String Address2_of_Organisation;
    private String Address3_of_Organisation;
    private String Organize_Landmark;
    private String Organize_Pincode;
    private String Organize_City;
    private String Organize_State;
    private String Organize_Country;
    private String Organize_LandlineNo;
    private String Gross_Income;
    private String Net_Income;
    private String Other_Income;
    private String Total_Income;
    private String IFSC_Code_Bank1;
    private String Bank1_Name;
    private String Bank1_AcctType;
    private String Bank1_AcctNo;
    private String IFSC_Code_Bank2;
    private String Bank2_Name;
    private String Bank2_AcctType;
    private String Bank2_AcctNo;
    private String Bank_Loan1;
    private String Type_Loan1;
    private String Amnt_Loan1;
    private String EMI_Loan1;
    private String Bank_Loan2;
    private String Type_Loan2;
    private String Amnt_Loan2;
    private String EMI_Loan2;
    private String Vehicle_Type;
    private String MakenModel_Vehicle;
    private String Dt_Purchase;
    private String Hypo_To;
    private String Vehicle_Type2;
    private String MakenModel_Vehicle2;
    private String Dt_Purchase2;
    private String Hypo_To2;
    private String Co_Title;
    private String Co_First_Name;
    private String Co_Middle_Name;
    private String Co_Last_Name;
    private String Co_Marital_Status;
    private String Co_Spouce_Name;
    private String Co_Mother_Name;
    private String Co_Category_Id;
    private String Co_No_Of_Dependent;
    private String Co_PAN_No;
    private String Co_Passport_No;
    private String Co_Driving_Lic_No;
    private String Co_Aadhar_Card_No;
    private String Co_Voters_Id;
    private String Co_DOB;
    private String Co_Status_Id;
    private String Co_Gender;
    private String Co_Nationality;
    private String Co_Id_Type;
    private String Co_Id_No;
    private String Co_Institute_University;
    private String Co_Mothers_Maidan_Name;
    private String Co_Education_Id;
    private String Co_Mobile_No1;
    private String Co_Mobile_No2;
    private String Co_Per_Email_Id;
    private String Co_Ofc_Email_Id;
    private String Co_Address1;
    private String Co_Address2;
    private String Co_Address3;
    private String Co_Landmark;
    private String Co_Pincode;
    private String Co_City;
    private String Co_State;
    private String Co_Country;
    private String Co_LandlineNo;
    private String Co_AddrsYrs;
    private String Co_Per_Address1;
    private String Co_Per_Address2;
    private String Co_Per_Address3;
    private String Co_Per_Landmark;
    private String Co_Per_Pincode;
    private String Co_Per_City;
    private String Co_Per_State;
    private String Co_Per_Country;
    private String Co_Per_LandlineNo;
    private String Co_Per_AddrsYrs;
    private String Co_Nature_Of_Employer;
    private String Co_Nature_Of_Organization;
    private String Co_Nature_Of_Business;
    private String Co_Designation;
    private String Co_Currnet_Employment_Period;
    private String Co_Total_Employment_Period;
    private String Co_Name_of_Organisation;
    private String Co_Address1_of_Organisation;
    private String Co_Address2_of_Organisation;
    private String Co_Address3_of_Organisation;
    private String Co_Organize_Landmark;
    private String Co_Organize_Pincode;
    private String Co_Organize_City;
    private String Co_Organize_State;
    private String Co_Organize_Country;
    private String Co_Organize_LandlineNo;
    private String Co_Gross_Income;
    private String Co_Net_Income;
    private String Co_Other_Income;
    private String Co_Total_Income;
    private String Co_IFSC_Code_Bank1;
    private String Co_Bank1_Name;
    private String Co_Bank1_AcctType;
    private String Co_Bank1_AcctNo;
    private String Co_IFSC_Code_Bank2;
    private String Co_Bank2_Name;
    private String Co_Bank2_AcctType;
    private String Co_Bank2_AcctNo;
    private String Co_Bank_Loan1;
    private String Co_Type_Loan1;
    private String Co_Amnt_Loan1;
    private String Co_EMI_Loan1;
    private String Co_Bank_Loan2;
    private String Co_Type_Loan2;
    private String Co_Amnt_Loan2;
    private String Co_EMI_Loan2;
    private String Co_Vehicle_Type;
    private String Co_MakenModel_Vehicle;
    private String Co_Dt_Purchase;
    private String Co_Hypo_To;
    private String Co_Vehicle_Type2;
    private String Co_MakenModel_Vehicle2;
    private String Co_Dt_Purchase2;
    private String Co_Hypo_To2;
    private String Prop_Loan_Amount;
    private String Prop_Terms;
    private String Purpose_Of_Loan;
    private String Repayment_Mode;
    private String Prop_Id_Type;
    private String Prop_Processing_Fee;
    private String Cheque_No;
    private String Cheque_Date;
    private String Drawn_On;
    private String Loan_Cost;
    private String Purchase_Price;
    private String Amenities;
    private String Other_Cost;
    private String Own_contri_Paid;
    private String Own_contri_Payable;
    private String Personal_Loan_Other;
    private String Loan_Requested;
    private String Trans_type;
    private String Construction_stage;
    private String expected_Completion;
    private String Land_area;
    private String Built_up_area;
    private String Prop_Ownership_Name;
    private String Prop_type;
    private String Prop_Age;
    private String Prop_Use;
    private String Expect_Month_rent;
    private String Prop_Address1;
    private String Prop_Address2;
    private String Prop_Address3;
    private String Prop_Landmark;
    private String Prop_Pincode;
    private String Prop_City;
    private String Prop_State;
    private String Prop_County;
    private String Msc_Ref1_Name;
    private String Msc_Ref1_Pin_code;
    private String Msc_Ref1_Landline_No;
    private String Msc_Ref1_Mob_No;
    private String Msc_Ref2_Name;
    private String Msc_Ref2_Pin_code;
    private String Msc_Ref2_Landline_No;
    private String Msc_Ref2_Mob_No;
    private String id;
    private String Datetime_Created;
    private String Ip_Address;
    private String UserId;
    private String LandlineNo_StdCode;
    private String Per_LandlineNo_StdCode;
    private String Organize_LandlineNo_StdCode;
    private String Co_LandlineNo_StdCode;
    private String Co_Per_LandlineNo_StdCode;
    private String Co_Organize_LandlineNo_StdCode;
    private String Msc_Ref1_LandlineNo_StdCode;
    private String Msc_Ref2_LandlineNo_StdCode;
    private int BankId;
    private int BrokerId;
    private int Is_ApplnComplete;
    private int ProductId;
    private int Is_Confirm;
    private int IsCoApp;
    private String Turn_Over;
    private String Depreciation;
    private String Director_Remuneration;
    private String Profit_Aft_Tax;
    private String Co_Turn_Over;
    private String Co_Depreciation;
    private String Co_Director_Remuneration;
    private String Co_Profit_Aft_Tax;
    private String FBA_Reg_Id;
    private String Appln_Source;
    private String sourcelink;
    private String CampaignName;
    private String dc_fba_reg;
    private String RBA_Source;

    public ErpHomeLoanRequest() {
        ApplnId = 0;
        Level = "";
        Quote_id = 0;
        Residence_Type = "";
        Co_Residence_Type = "";
        empCode ="";
        Title = "";
        First_Name = "";
        Middle_Name = "";
        Last_Name = "";
        Marital_Status = "";
        Spouce_Name = "";
        Mother_Name = "";
        Category_Id = "";
        No_Of_Dependent = "";
        PAN_No = "";
        Passport_No =  "";
        Driving_Lic_No =  "";
        Aadhar_Card_No =  "";
        Voters_Id =  "";
        DOB =  "";
        Status_Id =  "";
        Gender = "";
        Nationality =  "";
        Id_Type =  "";
        Id_No =  "";
        Institute_University =  "";
        Mothers_Maidan_Name =  "";
        Education_Id =  "";
        Mobile_No1 = "";
        Mobile_No2 =  "";
        Per_Email_Id =  "";
        Ofc_Email_Id = "";
        Address1 =  "";
        Address2 =  "";
        Address3 =  "";
        Landmark =  "";
        Pincode =  "";
        City =  "";
        State =  "";
        Country =  "";
        LandlineNo =  "";
        AddrsYrs =  "";
        Per_Address1 ="";
        Per_Address2 = "";
        Per_Address3 ="";
        Per_Landmark ="";
        Per_Pincode = "";
        Per_City = "";
        Per_State = "";
        Per_Country = "";
        Per_LandlineNo ="";
        Per_AddrsYrs ="";
        Nature_Of_Employer = "";
        Nature_Of_Organization = "";
        Nature_Of_Business = "";
        Designation = "";
        Currnet_Employment_Period = "";
        Total_Employment_Period = "";
        Name_of_Organisation = "";
        Address1_of_Organisation = "";
        Address2_of_Organisation = "";
        Address3_of_Organisation = "";
        Organize_Landmark ="";
        Organize_Pincode = "";
        Organize_City = "";
        Organize_State = "";
        Organize_Country = "";
        Organize_LandlineNo = "";
        Gross_Income ="";
        Net_Income ="";
        Other_Income = "";
        Total_Income ="";
        IFSC_Code_Bank1 = "";
        Bank1_Name = "";
        Bank1_AcctType = "";
        Bank1_AcctNo = "";
        IFSC_Code_Bank2 = "";
        Bank2_Name = "";
        Bank2_AcctType = "";
        Bank2_AcctNo = "";
        Bank_Loan1 = "";
        Type_Loan1 = "";
        Amnt_Loan1 = "";
        EMI_Loan1 = "";
        Bank_Loan2 = "";
        Type_Loan2 = "";
        Amnt_Loan2 ="";
        EMI_Loan2 = "";
        Vehicle_Type = "";
        MakenModel_Vehicle = "";
        Dt_Purchase = "";
        Hypo_To = "";
        Vehicle_Type2 = "";
        MakenModel_Vehicle2 ="";
        Dt_Purchase2 = "";
        Hypo_To2 = "";
        Co_Title = "";
        Co_First_Name = "";
        Co_Middle_Name = "";
        Co_Last_Name = "";
        Co_Marital_Status = "";
        Co_Spouce_Name = "";
        Co_Mother_Name = "";
        Co_Category_Id = "";
        Co_No_Of_Dependent = "";
        Co_PAN_No = "";
        Co_Passport_No = "";
        Co_Driving_Lic_No = "";
        Co_Aadhar_Card_No ="";
        Co_Voters_Id = "";
        Co_DOB = "";
        Co_Status_Id = "";
        Co_Gender = "";
        Co_Nationality = "";
        Co_Id_Type = "";
        Co_Id_No = "";
        Co_Institute_University = "";
        Co_Mothers_Maidan_Name = "";
        Co_Education_Id = "";
        Co_Mobile_No1 = "";
        Co_Mobile_No2 = "";
        Co_Per_Email_Id = "";
        Co_Ofc_Email_Id = "";
        Co_Address1 = "";
        Co_Address2 = "";
        Co_Address3 = "";
        Co_Landmark = "";
        Co_Pincode = "";
        Co_City = "";
        Co_State = "";
        Co_Country = "";
        Co_LandlineNo = "";
        Co_AddrsYrs = "";
        Co_Per_Address1 = "";
        Co_Per_Address2 = "";
        Co_Per_Address3 = "";
        Co_Per_Landmark = "";
        Co_Per_Pincode = "";
        Co_Per_City = "";
        Co_Per_State = "";
        Co_Per_Country = "";
        Co_Per_LandlineNo = "";
        Co_Per_AddrsYrs = "";
        Co_Nature_Of_Employer = "";
        Co_Nature_Of_Organization = "";
        Co_Nature_Of_Business ="";
        Co_Designation = "";
        Co_Currnet_Employment_Period = "";
        Co_Total_Employment_Period = "";
        Co_Name_of_Organisation = "";
        Co_Address1_of_Organisation = "";
        Co_Address2_of_Organisation = "";
        Co_Address3_of_Organisation = "";
        Co_Organize_Landmark = "";
        Co_Organize_Pincode = "";
        Co_Organize_City = "";
        Co_Organize_State = "";
        Co_Organize_Country = "";
        Co_Organize_LandlineNo = "";
        Co_Gross_Income = "";
        Co_Net_Income = "";
        Co_Other_Income = "";
        Co_Total_Income = "";
        Co_IFSC_Code_Bank1 = "";
        Co_Bank1_Name = "";
        Co_Bank1_AcctType = "";
        Co_Bank1_AcctNo = "";
        Co_IFSC_Code_Bank2 = "";
        Co_Bank2_Name = "";
        Co_Bank2_AcctType = "";
        Co_Bank2_AcctNo = "";
        Co_Bank_Loan1 = "";
        Co_Type_Loan1 = "";
        Co_Amnt_Loan1 = "";
        Co_EMI_Loan1 = "";
        Co_Bank_Loan2 = "";
        Co_Type_Loan2 = "";
        Co_Amnt_Loan2 = "";
        Co_EMI_Loan2 = "";
        Co_Vehicle_Type = "";
        Co_MakenModel_Vehicle = "";
        Co_Dt_Purchase ="";
        Co_Hypo_To = "";
        Co_Vehicle_Type2 = "";
        Co_MakenModel_Vehicle2 = "";
        Co_Dt_Purchase2 = "";
        Co_Hypo_To2 = "";
        Prop_Loan_Amount = "";
        Prop_Terms = "";
        Purpose_Of_Loan = "";
        Repayment_Mode = "";
        Prop_Id_Type = "";
        Prop_Processing_Fee = "";
        Cheque_No = "";
        Cheque_Date ="";
        Drawn_On = "";
        Loan_Cost = "";
        Purchase_Price = "";
        Amenities = "";
        Other_Cost = "";
        Own_contri_Paid = "";
        Own_contri_Payable = "";
        Personal_Loan_Other = "";
        Loan_Requested = "";
        Trans_type = "";
        Construction_stage ="";
        expected_Completion ="";
        Land_area = "";
        Built_up_area = "";
        Prop_Ownership_Name = "";
        Prop_type = "";
        Prop_Age = "";
        Prop_Use = "";
        Expect_Month_rent = "";
        Prop_Address1 = "";
        Prop_Address2 ="";
        Prop_Address3 = "";
        Prop_Landmark = "";
        Prop_Pincode ="";
        Prop_City ="";
        Prop_State = "";
        Prop_County = "";
        Msc_Ref1_Name = "";
        Msc_Ref1_Pin_code = "";
        Msc_Ref1_Landline_No = "";
        Msc_Ref1_Mob_No = "";
        Msc_Ref2_Name = "";
        Msc_Ref2_Pin_code = "";
        Msc_Ref2_Landline_No ="";
        Msc_Ref2_Mob_No = "";
        id = id;
        Datetime_Created = "";
        Ip_Address = "";
        UserId = "";
        LandlineNo_StdCode = "";
        Per_LandlineNo_StdCode = "";
        Organize_LandlineNo_StdCode = "";
        Co_LandlineNo_StdCode ="";
        Co_Per_LandlineNo_StdCode = "";
        Co_Organize_LandlineNo_StdCode = "";
        Msc_Ref1_LandlineNo_StdCode = "";
        Msc_Ref2_LandlineNo_StdCode = "";
        BankId = 0;
        BrokerId = 0;
        Is_ApplnComplete = 0;
        ProductId = 0;
        Is_Confirm = 0;
        IsCoApp = 0;
        Turn_Over =  "";
        Depreciation =  "";
        Director_Remuneration =  "";
        Profit_Aft_Tax = "";
        Co_Turn_Over =  "";
        Co_Depreciation =  "";
        Co_Director_Remuneration =  "";
        Co_Profit_Aft_Tax =  "";
        FBA_Reg_Id = "";
        Appln_Source =  "";
        sourcelink =  "";
        CampaignName = "";
        dc_fba_reg = "";
        RBA_Source =  "";
    }

    public int getApplnId() {
        return ApplnId;
    }

    public void setApplnId(int ApplnId) {
        this.ApplnId = ApplnId;
    }

    public String getLevel() {
        return Level;
    }

    public void setLevel(String Level) {
        this.Level = Level;
    }

    public int getQuote_id() {
        return Quote_id;
    }

    public void setQuote_id(int Quote_id) {
        this.Quote_id = Quote_id;
    }

    public String getResidence_Type() {
        return Residence_Type;
    }

    public void setResidence_Type(String Residence_Type) {
        this.Residence_Type = Residence_Type;
    }

    public String getCo_Residence_Type() {
        return Co_Residence_Type;
    }

    public void setCo_Residence_Type(String Co_Residence_Type) {
        this.Co_Residence_Type = Co_Residence_Type;
    }

    public String getEmpCode() {
        return empCode;
    }

    public void setEmpCode(String empCode) {
        this.empCode = empCode;
    }

    public String getTitle() {
        return Title;
    }

    public void setTitle(String Title) {
        this.Title = Title;
    }

    public String getFirst_Name() {
        return First_Name;
    }

    public void setFirst_Name(String First_Name) {
        this.First_Name = First_Name;
    }

    public String getMiddle_Name() {
        return Middle_Name;
    }

    public void setMiddle_Name(String Middle_Name) {
        this.Middle_Name = Middle_Name;
    }

    public String getLast_Name() {
        return Last_Name;
    }

    public void setLast_Name(String Last_Name) {
        this.Last_Name = Last_Name;
    }

    public String getMarital_Status() {
        return Marital_Status;
    }

    public void setMarital_Status(String Marital_Status) {
        this.Marital_Status = Marital_Status;
    }

    public String getSpouce_Name() {
        return Spouce_Name;
    }

    public void setSpouce_Name(String Spouce_Name) {
        this.Spouce_Name = Spouce_Name;
    }

    public String getMother_Name() {
        return Mother_Name;
    }

    public void setMother_Name(String Mother_Name) {
        this.Mother_Name = Mother_Name;
    }

    public String getCategory_Id() {
        return Category_Id;
    }

    public void setCategory_Id(String Category_Id) {
        this.Category_Id = Category_Id;
    }

    public String getNo_Of_Dependent() {
        return No_Of_Dependent;
    }

    public void setNo_Of_Dependent(String No_Of_Dependent) {
        this.No_Of_Dependent = No_Of_Dependent;
    }

    public String getPAN_No() {
        return PAN_No;
    }

    public void setPAN_No(String PAN_No) {
        this.PAN_No = PAN_No;
    }

    public String getPassport_No() {
        return Passport_No;
    }

    public void setPassport_No(String Passport_No) {
        this.Passport_No = Passport_No;
    }

    public String getDriving_Lic_No() {
        return Driving_Lic_No;
    }

    public void setDriving_Lic_No(String Driving_Lic_No) {
        this.Driving_Lic_No = Driving_Lic_No;
    }

    public String getAadhar_Card_No() {
        return Aadhar_Card_No;
    }

    public void setAadhar_Card_No(String Aadhar_Card_No) {
        this.Aadhar_Card_No = Aadhar_Card_No;
    }

    public String getVoters_Id() {
        return Voters_Id;
    }

    public void setVoters_Id(String Voters_Id) {
        this.Voters_Id = Voters_Id;
    }

    public String getDOB() {
        return DOB;
    }

    public void setDOB(String DOB) {
        this.DOB = DOB;
    }

    public String getStatus_Id() {
        return Status_Id;
    }

    public void setStatus_Id(String Status_Id) {
        this.Status_Id = Status_Id;
    }

    public String getGender() {
        return Gender;
    }

    public void setGender(String Gender) {
        this.Gender = Gender;
    }

    public String getNationality() {
        return Nationality;
    }

    public void setNationality(String Nationality) {
        this.Nationality = Nationality;
    }

    public String getId_Type() {
        return Id_Type;
    }

    public void setId_Type(String Id_Type) {
        this.Id_Type = Id_Type;
    }

    public String getId_No() {
        return Id_No;
    }

    public void setId_No(String Id_No) {
        this.Id_No = Id_No;
    }

    public String getInstitute_University() {
        return Institute_University;
    }

    public void setInstitute_University(String Institute_University) {
        this.Institute_University = Institute_University;
    }

    public String getMothers_Maidan_Name() {
        return Mothers_Maidan_Name;
    }

    public void setMothers_Maidan_Name(String Mothers_Maidan_Name) {
        this.Mothers_Maidan_Name = Mothers_Maidan_Name;
    }

    public String getEducation_Id() {
        return Education_Id;
    }

    public void setEducation_Id(String Education_Id) {
        this.Education_Id = Education_Id;
    }

    public String getMobile_No1() {
        return Mobile_No1;
    }

    public void setMobile_No1(String Mobile_No1) {
        this.Mobile_No1 = Mobile_No1;
    }

    public String getMobile_No2() {
        return Mobile_No2;
    }

    public void setMobile_No2(String Mobile_No2) {
        this.Mobile_No2 = Mobile_No2;
    }

    public String getPer_Email_Id() {
        return Per_Email_Id;
    }

    public void setPer_Email_Id(String Per_Email_Id) {
        this.Per_Email_Id = Per_Email_Id;
    }

    public String getOfc_Email_Id() {
        return Ofc_Email_Id;
    }

    public void setOfc_Email_Id(String Ofc_Email_Id) {
        this.Ofc_Email_Id = Ofc_Email_Id;
    }

    public String getAddress1() {
        return Address1;
    }

    public void setAddress1(String Address1) {
        this.Address1 = Address1;
    }

    public String getAddress2() {
        return Address2;
    }

    public void setAddress2(String Address2) {
        this.Address2 = Address2;
    }

    public String getAddress3() {
        return Address3;
    }

    public void setAddress3(String Address3) {
        this.Address3 = Address3;
    }

    public String getLandmark() {
        return Landmark;
    }

    public void setLandmark(String Landmark) {
        this.Landmark = Landmark;
    }

    public String getPincode() {
        return Pincode;
    }

    public void setPincode(String Pincode) {
        this.Pincode = Pincode;
    }

    public String getCity() {
        return City;
    }

    public void setCity(String City) {
        this.City = City;
    }

    public String getState() {
        return State;
    }

    public void setState(String State) {
        this.State = State;
    }

    public String getCountry() {
        return Country;
    }

    public void setCountry(String Country) {
        this.Country = Country;
    }

    public String getLandlineNo() {
        return LandlineNo;
    }

    public void setLandlineNo(String LandlineNo) {
        this.LandlineNo = LandlineNo;
    }

    public String getAddrsYrs() {
        return AddrsYrs;
    }

    public void setAddrsYrs(String AddrsYrs) {
        this.AddrsYrs = AddrsYrs;
    }

    public String getPer_Address1() {
        return Per_Address1;
    }

    public void setPer_Address1(String Per_Address1) {
        this.Per_Address1 = Per_Address1;
    }

    public String getPer_Address2() {
        return Per_Address2;
    }

    public void setPer_Address2(String Per_Address2) {
        this.Per_Address2 = Per_Address2;
    }

    public String getPer_Address3() {
        return Per_Address3;
    }

    public void setPer_Address3(String Per_Address3) {
        this.Per_Address3 = Per_Address3;
    }

    public String getPer_Landmark() {
        return Per_Landmark;
    }

    public void setPer_Landmark(String Per_Landmark) {
        this.Per_Landmark = Per_Landmark;
    }

    public String getPer_Pincode() {
        return Per_Pincode;
    }

    public void setPer_Pincode(String Per_Pincode) {
        this.Per_Pincode = Per_Pincode;
    }

    public String getPer_City() {
        return Per_City;
    }

    public void setPer_City(String Per_City) {
        this.Per_City = Per_City;
    }

    public String getPer_State() {
        return Per_State;
    }

    public void setPer_State(String Per_State) {
        this.Per_State = Per_State;
    }

    public String getPer_Country() {
        return Per_Country;
    }

    public void setPer_Country(String Per_Country) {
        this.Per_Country = Per_Country;
    }

    public String getPer_LandlineNo() {
        return Per_LandlineNo;
    }

    public void setPer_LandlineNo(String Per_LandlineNo) {
        this.Per_LandlineNo = Per_LandlineNo;
    }

    public String getPer_AddrsYrs() {
        return Per_AddrsYrs;
    }

    public void setPer_AddrsYrs(String Per_AddrsYrs) {
        this.Per_AddrsYrs = Per_AddrsYrs;
    }

    public String getNature_Of_Employer() {
        return Nature_Of_Employer;
    }

    public void setNature_Of_Employer(String Nature_Of_Employer) {
        this.Nature_Of_Employer = Nature_Of_Employer;
    }

    public String getNature_Of_Organization() {
        return Nature_Of_Organization;
    }

    public void setNature_Of_Organization(String Nature_Of_Organization) {
        this.Nature_Of_Organization = Nature_Of_Organization;
    }

    public String getNature_Of_Business() {
        return Nature_Of_Business;
    }

    public void setNature_Of_Business(String Nature_Of_Business) {
        this.Nature_Of_Business = Nature_Of_Business;
    }

    public String getDesignation() {
        return Designation;
    }

    public void setDesignation(String Designation) {
        this.Designation = Designation;
    }

    public String getCurrnet_Employment_Period() {
        return Currnet_Employment_Period;
    }

    public void setCurrnet_Employment_Period(String Currnet_Employment_Period) {
        this.Currnet_Employment_Period = Currnet_Employment_Period;
    }

    public String getTotal_Employment_Period() {
        return Total_Employment_Period;
    }

    public void setTotal_Employment_Period(String Total_Employment_Period) {
        this.Total_Employment_Period = Total_Employment_Period;
    }

    public String getName_of_Organisation() {
        return Name_of_Organisation;
    }

    public void setName_of_Organisation(String Name_of_Organisation) {
        this.Name_of_Organisation = Name_of_Organisation;
    }

    public String getAddress1_of_Organisation() {
        return Address1_of_Organisation;
    }

    public void setAddress1_of_Organisation(String Address1_of_Organisation) {
        this.Address1_of_Organisation = Address1_of_Organisation;
    }

    public String getAddress2_of_Organisation() {
        return Address2_of_Organisation;
    }

    public void setAddress2_of_Organisation(String Address2_of_Organisation) {
        this.Address2_of_Organisation = Address2_of_Organisation;
    }

    public String getAddress3_of_Organisation() {
        return Address3_of_Organisation;
    }

    public void setAddress3_of_Organisation(String Address3_of_Organisation) {
        this.Address3_of_Organisation = Address3_of_Organisation;
    }

    public String getOrganize_Landmark() {
        return Organize_Landmark;
    }

    public void setOrganize_Landmark(String Organize_Landmark) {
        this.Organize_Landmark = Organize_Landmark;
    }

    public String getOrganize_Pincode() {
        return Organize_Pincode;
    }

    public void setOrganize_Pincode(String Organize_Pincode) {
        this.Organize_Pincode = Organize_Pincode;
    }

    public String getOrganize_City() {
        return Organize_City;
    }

    public void setOrganize_City(String Organize_City) {
        this.Organize_City = Organize_City;
    }

    public String getOrganize_State() {
        return Organize_State;
    }

    public void setOrganize_State(String Organize_State) {
        this.Organize_State = Organize_State;
    }

    public String getOrganize_Country() {
        return Organize_Country;
    }

    public void setOrganize_Country(String Organize_Country) {
        this.Organize_Country = Organize_Country;
    }

    public String getOrganize_LandlineNo() {
        return Organize_LandlineNo;
    }

    public void setOrganize_LandlineNo(String Organize_LandlineNo) {
        this.Organize_LandlineNo = Organize_LandlineNo;
    }

    public String getGross_Income() {
        return Gross_Income;
    }

    public void setGross_Income(String Gross_Income) {
        this.Gross_Income = Gross_Income;
    }

    public String getNet_Income() {
        return Net_Income;
    }

    public void setNet_Income(String Net_Income) {
        this.Net_Income = Net_Income;
    }

    public String getOther_Income() {
        return Other_Income;
    }

    public void setOther_Income(String Other_Income) {
        this.Other_Income = Other_Income;
    }

    public String getTotal_Income() {
        return Total_Income;
    }

    public void setTotal_Income(String Total_Income) {
        this.Total_Income = Total_Income;
    }

    public String getIFSC_Code_Bank1() {
        return IFSC_Code_Bank1;
    }

    public void setIFSC_Code_Bank1(String IFSC_Code_Bank1) {
        this.IFSC_Code_Bank1 = IFSC_Code_Bank1;
    }

    public String getBank1_Name() {
        return Bank1_Name;
    }

    public void setBank1_Name(String Bank1_Name) {
        this.Bank1_Name = Bank1_Name;
    }

    public String getBank1_AcctType() {
        return Bank1_AcctType;
    }

    public void setBank1_AcctType(String Bank1_AcctType) {
        this.Bank1_AcctType = Bank1_AcctType;
    }

    public String getBank1_AcctNo() {
        return Bank1_AcctNo;
    }

    public void setBank1_AcctNo(String Bank1_AcctNo) {
        this.Bank1_AcctNo = Bank1_AcctNo;
    }

    public String getIFSC_Code_Bank2() {
        return IFSC_Code_Bank2;
    }

    public void setIFSC_Code_Bank2(String IFSC_Code_Bank2) {
        this.IFSC_Code_Bank2 = IFSC_Code_Bank2;
    }

    public String getBank2_Name() {
        return Bank2_Name;
    }

    public void setBank2_Name(String Bank2_Name) {
        this.Bank2_Name = Bank2_Name;
    }

    public String getBank2_AcctType() {
        return Bank2_AcctType;
    }

    public void setBank2_AcctType(String Bank2_AcctType) {
        this.Bank2_AcctType = Bank2_AcctType;
    }

    public String getBank2_AcctNo() {
        return Bank2_AcctNo;
    }

    public void setBank2_AcctNo(String Bank2_AcctNo) {
        this.Bank2_AcctNo = Bank2_AcctNo;
    }

    public String getBank_Loan1() {
        return Bank_Loan1;
    }

    public void setBank_Loan1(String Bank_Loan1) {
        this.Bank_Loan1 = Bank_Loan1;
    }

    public String getType_Loan1() {
        return Type_Loan1;
    }

    public void setType_Loan1(String Type_Loan1) {
        this.Type_Loan1 = Type_Loan1;
    }

    public String getAmnt_Loan1() {
        return Amnt_Loan1;
    }

    public void setAmnt_Loan1(String Amnt_Loan1) {
        this.Amnt_Loan1 = Amnt_Loan1;
    }

    public String getEMI_Loan1() {
        return EMI_Loan1;
    }

    public void setEMI_Loan1(String EMI_Loan1) {
        this.EMI_Loan1 = EMI_Loan1;
    }

    public String getBank_Loan2() {
        return Bank_Loan2;
    }

    public void setBank_Loan2(String Bank_Loan2) {
        this.Bank_Loan2 = Bank_Loan2;
    }

    public String getType_Loan2() {
        return Type_Loan2;
    }

    public void setType_Loan2(String Type_Loan2) {
        this.Type_Loan2 = Type_Loan2;
    }

    public String getAmnt_Loan2() {
        return Amnt_Loan2;
    }

    public void setAmnt_Loan2(String Amnt_Loan2) {
        this.Amnt_Loan2 = Amnt_Loan2;
    }

    public String getEMI_Loan2() {
        return EMI_Loan2;
    }

    public void setEMI_Loan2(String EMI_Loan2) {
        this.EMI_Loan2 = EMI_Loan2;
    }

    public String getVehicle_Type() {
        return Vehicle_Type;
    }

    public void setVehicle_Type(String Vehicle_Type) {
        this.Vehicle_Type = Vehicle_Type;
    }

    public String getMakenModel_Vehicle() {
        return MakenModel_Vehicle;
    }

    public void setMakenModel_Vehicle(String MakenModel_Vehicle) {
        this.MakenModel_Vehicle = MakenModel_Vehicle;
    }

    public String getDt_Purchase() {
        return Dt_Purchase;
    }

    public void setDt_Purchase(String Dt_Purchase) {
        this.Dt_Purchase = Dt_Purchase;
    }

    public String getHypo_To() {
        return Hypo_To;
    }

    public void setHypo_To(String Hypo_To) {
        this.Hypo_To = Hypo_To;
    }

    public String getVehicle_Type2() {
        return Vehicle_Type2;
    }

    public void setVehicle_Type2(String Vehicle_Type2) {
        this.Vehicle_Type2 = Vehicle_Type2;
    }

    public String getMakenModel_Vehicle2() {
        return MakenModel_Vehicle2;
    }

    public void setMakenModel_Vehicle2(String MakenModel_Vehicle2) {
        this.MakenModel_Vehicle2 = MakenModel_Vehicle2;
    }

    public String getDt_Purchase2() {
        return Dt_Purchase2;
    }

    public void setDt_Purchase2(String Dt_Purchase2) {
        this.Dt_Purchase2 = Dt_Purchase2;
    }

    public String getHypo_To2() {
        return Hypo_To2;
    }

    public void setHypo_To2(String Hypo_To2) {
        this.Hypo_To2 = Hypo_To2;
    }

    public String getCo_Title() {
        return Co_Title;
    }

    public void setCo_Title(String Co_Title) {
        this.Co_Title = Co_Title;
    }

    public String getCo_First_Name() {
        return Co_First_Name;
    }

    public void setCo_First_Name(String Co_First_Name) {
        this.Co_First_Name = Co_First_Name;
    }

    public String getCo_Middle_Name() {
        return Co_Middle_Name;
    }

    public void setCo_Middle_Name(String Co_Middle_Name) {
        this.Co_Middle_Name = Co_Middle_Name;
    }

    public String getCo_Last_Name() {
        return Co_Last_Name;
    }

    public void setCo_Last_Name(String Co_Last_Name) {
        this.Co_Last_Name = Co_Last_Name;
    }

    public String getCo_Marital_Status() {
        return Co_Marital_Status;
    }

    public void setCo_Marital_Status(String Co_Marital_Status) {
        this.Co_Marital_Status = Co_Marital_Status;
    }

    public String getCo_Spouce_Name() {
        return Co_Spouce_Name;
    }

    public void setCo_Spouce_Name(String Co_Spouce_Name) {
        this.Co_Spouce_Name = Co_Spouce_Name;
    }

    public String getCo_Mother_Name() {
        return Co_Mother_Name;
    }

    public void setCo_Mother_Name(String Co_Mother_Name) {
        this.Co_Mother_Name = Co_Mother_Name;
    }

    public String getCo_Category_Id() {
        return Co_Category_Id;
    }

    public void setCo_Category_Id(String Co_Category_Id) {
        this.Co_Category_Id = Co_Category_Id;
    }

    public String getCo_No_Of_Dependent() {
        return Co_No_Of_Dependent;
    }

    public void setCo_No_Of_Dependent(String Co_No_Of_Dependent) {
        this.Co_No_Of_Dependent = Co_No_Of_Dependent;
    }

    public String getCo_PAN_No() {
        return Co_PAN_No;
    }

    public void setCo_PAN_No(String Co_PAN_No) {
        this.Co_PAN_No = Co_PAN_No;
    }

    public String getCo_Passport_No() {
        return Co_Passport_No;
    }

    public void setCo_Passport_No(String Co_Passport_No) {
        this.Co_Passport_No = Co_Passport_No;
    }

    public String getCo_Driving_Lic_No() {
        return Co_Driving_Lic_No;
    }

    public void setCo_Driving_Lic_No(String Co_Driving_Lic_No) {
        this.Co_Driving_Lic_No = Co_Driving_Lic_No;
    }

    public String getCo_Aadhar_Card_No() {
        return Co_Aadhar_Card_No;
    }

    public void setCo_Aadhar_Card_No(String Co_Aadhar_Card_No) {
        this.Co_Aadhar_Card_No = Co_Aadhar_Card_No;
    }

    public String getCo_Voters_Id() {
        return Co_Voters_Id;
    }

    public void setCo_Voters_Id(String Co_Voters_Id) {
        this.Co_Voters_Id = Co_Voters_Id;
    }

    public String getCo_DOB() {
        return Co_DOB;
    }

    public void setCo_DOB(String Co_DOB) {
        this.Co_DOB = Co_DOB;
    }

    public String getCo_Status_Id() {
        return Co_Status_Id;
    }

    public void setCo_Status_Id(String Co_Status_Id) {
        this.Co_Status_Id = Co_Status_Id;
    }

    public String getCo_Gender() {
        return Co_Gender;
    }

    public void setCo_Gender(String Co_Gender) {
        this.Co_Gender = Co_Gender;
    }

    public String getCo_Nationality() {
        return Co_Nationality;
    }

    public void setCo_Nationality(String Co_Nationality) {
        this.Co_Nationality = Co_Nationality;
    }

    public String getCo_Id_Type() {
        return Co_Id_Type;
    }

    public void setCo_Id_Type(String Co_Id_Type) {
        this.Co_Id_Type = Co_Id_Type;
    }

    public String getCo_Id_No() {
        return Co_Id_No;
    }

    public void setCo_Id_No(String Co_Id_No) {
        this.Co_Id_No = Co_Id_No;
    }

    public String getCo_Institute_University() {
        return Co_Institute_University;
    }

    public void setCo_Institute_University(String Co_Institute_University) {
        this.Co_Institute_University = Co_Institute_University;
    }

    public String getCo_Mothers_Maidan_Name() {
        return Co_Mothers_Maidan_Name;
    }

    public void setCo_Mothers_Maidan_Name(String Co_Mothers_Maidan_Name) {
        this.Co_Mothers_Maidan_Name = Co_Mothers_Maidan_Name;
    }

    public String getCo_Education_Id() {
        return Co_Education_Id;
    }

    public void setCo_Education_Id(String Co_Education_Id) {
        this.Co_Education_Id = Co_Education_Id;
    }

    public String getCo_Mobile_No1() {
        return Co_Mobile_No1;
    }

    public void setCo_Mobile_No1(String Co_Mobile_No1) {
        this.Co_Mobile_No1 = Co_Mobile_No1;
    }

    public String getCo_Mobile_No2() {
        return Co_Mobile_No2;
    }

    public void setCo_Mobile_No2(String Co_Mobile_No2) {
        this.Co_Mobile_No2 = Co_Mobile_No2;
    }

    public String getCo_Per_Email_Id() {
        return Co_Per_Email_Id;
    }

    public void setCo_Per_Email_Id(String Co_Per_Email_Id) {
        this.Co_Per_Email_Id = Co_Per_Email_Id;
    }

    public String getCo_Ofc_Email_Id() {
        return Co_Ofc_Email_Id;
    }

    public void setCo_Ofc_Email_Id(String Co_Ofc_Email_Id) {
        this.Co_Ofc_Email_Id = Co_Ofc_Email_Id;
    }

    public String getCo_Address1() {
        return Co_Address1;
    }

    public void setCo_Address1(String Co_Address1) {
        this.Co_Address1 = Co_Address1;
    }

    public String getCo_Address2() {
        return Co_Address2;
    }

    public void setCo_Address2(String Co_Address2) {
        this.Co_Address2 = Co_Address2;
    }

    public String getCo_Address3() {
        return Co_Address3;
    }

    public void setCo_Address3(String Co_Address3) {
        this.Co_Address3 = Co_Address3;
    }

    public String getCo_Landmark() {
        return Co_Landmark;
    }

    public void setCo_Landmark(String Co_Landmark) {
        this.Co_Landmark = Co_Landmark;
    }

    public String getCo_Pincode() {
        return Co_Pincode;
    }

    public void setCo_Pincode(String Co_Pincode) {
        this.Co_Pincode = Co_Pincode;
    }

    public String getCo_City() {
        return Co_City;
    }

    public void setCo_City(String Co_City) {
        this.Co_City = Co_City;
    }

    public String getCo_State() {
        return Co_State;
    }

    public void setCo_State(String Co_State) {
        this.Co_State = Co_State;
    }

    public String getCo_Country() {
        return Co_Country;
    }

    public void setCo_Country(String Co_Country) {
        this.Co_Country = Co_Country;
    }

    public String getCo_LandlineNo() {
        return Co_LandlineNo;
    }

    public void setCo_LandlineNo(String Co_LandlineNo) {
        this.Co_LandlineNo = Co_LandlineNo;
    }

    public String getCo_AddrsYrs() {
        return Co_AddrsYrs;
    }

    public void setCo_AddrsYrs(String Co_AddrsYrs) {
        this.Co_AddrsYrs = Co_AddrsYrs;
    }

    public String getCo_Per_Address1() {
        return Co_Per_Address1;
    }

    public void setCo_Per_Address1(String Co_Per_Address1) {
        this.Co_Per_Address1 = Co_Per_Address1;
    }

    public String getCo_Per_Address2() {
        return Co_Per_Address2;
    }

    public void setCo_Per_Address2(String Co_Per_Address2) {
        this.Co_Per_Address2 = Co_Per_Address2;
    }

    public String getCo_Per_Address3() {
        return Co_Per_Address3;
    }

    public void setCo_Per_Address3(String Co_Per_Address3) {
        this.Co_Per_Address3 = Co_Per_Address3;
    }

    public String getCo_Per_Landmark() {
        return Co_Per_Landmark;
    }

    public void setCo_Per_Landmark(String Co_Per_Landmark) {
        this.Co_Per_Landmark = Co_Per_Landmark;
    }

    public String getCo_Per_Pincode() {
        return Co_Per_Pincode;
    }

    public void setCo_Per_Pincode(String Co_Per_Pincode) {
        this.Co_Per_Pincode = Co_Per_Pincode;
    }

    public String getCo_Per_City() {
        return Co_Per_City;
    }

    public void setCo_Per_City(String Co_Per_City) {
        this.Co_Per_City = Co_Per_City;
    }

    public String getCo_Per_State() {
        return Co_Per_State;
    }

    public void setCo_Per_State(String Co_Per_State) {
        this.Co_Per_State = Co_Per_State;
    }

    public String getCo_Per_Country() {
        return Co_Per_Country;
    }

    public void setCo_Per_Country(String Co_Per_Country) {
        this.Co_Per_Country = Co_Per_Country;
    }

    public String getCo_Per_LandlineNo() {
        return Co_Per_LandlineNo;
    }

    public void setCo_Per_LandlineNo(String Co_Per_LandlineNo) {
        this.Co_Per_LandlineNo = Co_Per_LandlineNo;
    }

    public String getCo_Per_AddrsYrs() {
        return Co_Per_AddrsYrs;
    }

    public void setCo_Per_AddrsYrs(String Co_Per_AddrsYrs) {
        this.Co_Per_AddrsYrs = Co_Per_AddrsYrs;
    }

    public String getCo_Nature_Of_Employer() {
        return Co_Nature_Of_Employer;
    }

    public void setCo_Nature_Of_Employer(String Co_Nature_Of_Employer) {
        this.Co_Nature_Of_Employer = Co_Nature_Of_Employer;
    }

    public String getCo_Nature_Of_Organization() {
        return Co_Nature_Of_Organization;
    }

    public void setCo_Nature_Of_Organization(String Co_Nature_Of_Organization) {
        this.Co_Nature_Of_Organization = Co_Nature_Of_Organization;
    }

    public String getCo_Nature_Of_Business() {
        return Co_Nature_Of_Business;
    }

    public void setCo_Nature_Of_Business(String Co_Nature_Of_Business) {
        this.Co_Nature_Of_Business = Co_Nature_Of_Business;
    }

    public String getCo_Designation() {
        return Co_Designation;
    }

    public void setCo_Designation(String Co_Designation) {
        this.Co_Designation = Co_Designation;
    }

    public String getCo_Currnet_Employment_Period() {
        return Co_Currnet_Employment_Period;
    }

    public void setCo_Currnet_Employment_Period(String Co_Currnet_Employment_Period) {
        this.Co_Currnet_Employment_Period = Co_Currnet_Employment_Period;
    }

    public String getCo_Total_Employment_Period() {
        return Co_Total_Employment_Period;
    }

    public void setCo_Total_Employment_Period(String Co_Total_Employment_Period) {
        this.Co_Total_Employment_Period = Co_Total_Employment_Period;
    }

    public String getCo_Name_of_Organisation() {
        return Co_Name_of_Organisation;
    }

    public void setCo_Name_of_Organisation(String Co_Name_of_Organisation) {
        this.Co_Name_of_Organisation = Co_Name_of_Organisation;
    }

    public String getCo_Address1_of_Organisation() {
        return Co_Address1_of_Organisation;
    }

    public void setCo_Address1_of_Organisation(String Co_Address1_of_Organisation) {
        this.Co_Address1_of_Organisation = Co_Address1_of_Organisation;
    }

    public String getCo_Address2_of_Organisation() {
        return Co_Address2_of_Organisation;
    }

    public void setCo_Address2_of_Organisation(String Co_Address2_of_Organisation) {
        this.Co_Address2_of_Organisation = Co_Address2_of_Organisation;
    }

    public String getCo_Address3_of_Organisation() {
        return Co_Address3_of_Organisation;
    }

    public void setCo_Address3_of_Organisation(String Co_Address3_of_Organisation) {
        this.Co_Address3_of_Organisation = Co_Address3_of_Organisation;
    }

    public String getCo_Organize_Landmark() {
        return Co_Organize_Landmark;
    }

    public void setCo_Organize_Landmark(String Co_Organize_Landmark) {
        this.Co_Organize_Landmark = Co_Organize_Landmark;
    }

    public String getCo_Organize_Pincode() {
        return Co_Organize_Pincode;
    }

    public void setCo_Organize_Pincode(String Co_Organize_Pincode) {
        this.Co_Organize_Pincode = Co_Organize_Pincode;
    }

    public String getCo_Organize_City() {
        return Co_Organize_City;
    }

    public void setCo_Organize_City(String Co_Organize_City) {
        this.Co_Organize_City = Co_Organize_City;
    }

    public String getCo_Organize_State() {
        return Co_Organize_State;
    }

    public void setCo_Organize_State(String Co_Organize_State) {
        this.Co_Organize_State = Co_Organize_State;
    }

    public String getCo_Organize_Country() {
        return Co_Organize_Country;
    }

    public void setCo_Organize_Country(String Co_Organize_Country) {
        this.Co_Organize_Country = Co_Organize_Country;
    }

    public String getCo_Organize_LandlineNo() {
        return Co_Organize_LandlineNo;
    }

    public void setCo_Organize_LandlineNo(String Co_Organize_LandlineNo) {
        this.Co_Organize_LandlineNo = Co_Organize_LandlineNo;
    }

    public String getCo_Gross_Income() {
        return Co_Gross_Income;
    }

    public void setCo_Gross_Income(String Co_Gross_Income) {
        this.Co_Gross_Income = Co_Gross_Income;
    }

    public String getCo_Net_Income() {
        return Co_Net_Income;
    }

    public void setCo_Net_Income(String Co_Net_Income) {
        this.Co_Net_Income = Co_Net_Income;
    }

    public String getCo_Other_Income() {
        return Co_Other_Income;
    }

    public void setCo_Other_Income(String Co_Other_Income) {
        this.Co_Other_Income = Co_Other_Income;
    }

    public String getCo_Total_Income() {
        return Co_Total_Income;
    }

    public void setCo_Total_Income(String Co_Total_Income) {
        this.Co_Total_Income = Co_Total_Income;
    }

    public String getCo_IFSC_Code_Bank1() {
        return Co_IFSC_Code_Bank1;
    }

    public void setCo_IFSC_Code_Bank1(String Co_IFSC_Code_Bank1) {
        this.Co_IFSC_Code_Bank1 = Co_IFSC_Code_Bank1;
    }

    public String getCo_Bank1_Name() {
        return Co_Bank1_Name;
    }

    public void setCo_Bank1_Name(String Co_Bank1_Name) {
        this.Co_Bank1_Name = Co_Bank1_Name;
    }

    public String getCo_Bank1_AcctType() {
        return Co_Bank1_AcctType;
    }

    public void setCo_Bank1_AcctType(String Co_Bank1_AcctType) {
        this.Co_Bank1_AcctType = Co_Bank1_AcctType;
    }

    public String getCo_Bank1_AcctNo() {
        return Co_Bank1_AcctNo;
    }

    public void setCo_Bank1_AcctNo(String Co_Bank1_AcctNo) {
        this.Co_Bank1_AcctNo = Co_Bank1_AcctNo;
    }

    public String getCo_IFSC_Code_Bank2() {
        return Co_IFSC_Code_Bank2;
    }

    public void setCo_IFSC_Code_Bank2(String Co_IFSC_Code_Bank2) {
        this.Co_IFSC_Code_Bank2 = Co_IFSC_Code_Bank2;
    }

    public String getCo_Bank2_Name() {
        return Co_Bank2_Name;
    }

    public void setCo_Bank2_Name(String Co_Bank2_Name) {
        this.Co_Bank2_Name = Co_Bank2_Name;
    }

    public String getCo_Bank2_AcctType() {
        return Co_Bank2_AcctType;
    }

    public void setCo_Bank2_AcctType(String Co_Bank2_AcctType) {
        this.Co_Bank2_AcctType = Co_Bank2_AcctType;
    }

    public String getCo_Bank2_AcctNo() {
        return Co_Bank2_AcctNo;
    }

    public void setCo_Bank2_AcctNo(String Co_Bank2_AcctNo) {
        this.Co_Bank2_AcctNo = Co_Bank2_AcctNo;
    }

    public String getCo_Bank_Loan1() {
        return Co_Bank_Loan1;
    }

    public void setCo_Bank_Loan1(String Co_Bank_Loan1) {
        this.Co_Bank_Loan1 = Co_Bank_Loan1;
    }

    public String getCo_Type_Loan1() {
        return Co_Type_Loan1;
    }

    public void setCo_Type_Loan1(String Co_Type_Loan1) {
        this.Co_Type_Loan1 = Co_Type_Loan1;
    }

    public String getCo_Amnt_Loan1() {
        return Co_Amnt_Loan1;
    }

    public void setCo_Amnt_Loan1(String Co_Amnt_Loan1) {
        this.Co_Amnt_Loan1 = Co_Amnt_Loan1;
    }

    public String getCo_EMI_Loan1() {
        return Co_EMI_Loan1;
    }

    public void setCo_EMI_Loan1(String Co_EMI_Loan1) {
        this.Co_EMI_Loan1 = Co_EMI_Loan1;
    }

    public String getCo_Bank_Loan2() {
        return Co_Bank_Loan2;
    }

    public void setCo_Bank_Loan2(String Co_Bank_Loan2) {
        this.Co_Bank_Loan2 = Co_Bank_Loan2;
    }

    public String getCo_Type_Loan2() {
        return Co_Type_Loan2;
    }

    public void setCo_Type_Loan2(String Co_Type_Loan2) {
        this.Co_Type_Loan2 = Co_Type_Loan2;
    }

    public String getCo_Amnt_Loan2() {
        return Co_Amnt_Loan2;
    }

    public void setCo_Amnt_Loan2(String Co_Amnt_Loan2) {
        this.Co_Amnt_Loan2 = Co_Amnt_Loan2;
    }

    public String getCo_EMI_Loan2() {
        return Co_EMI_Loan2;
    }

    public void setCo_EMI_Loan2(String Co_EMI_Loan2) {
        this.Co_EMI_Loan2 = Co_EMI_Loan2;
    }

    public String getCo_Vehicle_Type() {
        return Co_Vehicle_Type;
    }

    public void setCo_Vehicle_Type(String Co_Vehicle_Type) {
        this.Co_Vehicle_Type = Co_Vehicle_Type;
    }

    public String getCo_MakenModel_Vehicle() {
        return Co_MakenModel_Vehicle;
    }

    public void setCo_MakenModel_Vehicle(String Co_MakenModel_Vehicle) {
        this.Co_MakenModel_Vehicle = Co_MakenModel_Vehicle;
    }

    public String getCo_Dt_Purchase() {
        return Co_Dt_Purchase;
    }

    public void setCo_Dt_Purchase(String Co_Dt_Purchase) {
        this.Co_Dt_Purchase = Co_Dt_Purchase;
    }

    public String getCo_Hypo_To() {
        return Co_Hypo_To;
    }

    public void setCo_Hypo_To(String Co_Hypo_To) {
        this.Co_Hypo_To = Co_Hypo_To;
    }

    public String getCo_Vehicle_Type2() {
        return Co_Vehicle_Type2;
    }

    public void setCo_Vehicle_Type2(String Co_Vehicle_Type2) {
        this.Co_Vehicle_Type2 = Co_Vehicle_Type2;
    }

    public String getCo_MakenModel_Vehicle2() {
        return Co_MakenModel_Vehicle2;
    }

    public void setCo_MakenModel_Vehicle2(String Co_MakenModel_Vehicle2) {
        this.Co_MakenModel_Vehicle2 = Co_MakenModel_Vehicle2;
    }

    public String getCo_Dt_Purchase2() {
        return Co_Dt_Purchase2;
    }

    public void setCo_Dt_Purchase2(String Co_Dt_Purchase2) {
        this.Co_Dt_Purchase2 = Co_Dt_Purchase2;
    }

    public String getCo_Hypo_To2() {
        return Co_Hypo_To2;
    }

    public void setCo_Hypo_To2(String Co_Hypo_To2) {
        this.Co_Hypo_To2 = Co_Hypo_To2;
    }

    public String getProp_Loan_Amount() {
        return Prop_Loan_Amount;
    }

    public void setProp_Loan_Amount(String Prop_Loan_Amount) {
        this.Prop_Loan_Amount = Prop_Loan_Amount;
    }

    public String getProp_Terms() {
        return Prop_Terms;
    }

    public void setProp_Terms(String Prop_Terms) {
        this.Prop_Terms = Prop_Terms;
    }

    public String getPurpose_Of_Loan() {
        return Purpose_Of_Loan;
    }

    public void setPurpose_Of_Loan(String Purpose_Of_Loan) {
        this.Purpose_Of_Loan = Purpose_Of_Loan;
    }

    public String getRepayment_Mode() {
        return Repayment_Mode;
    }

    public void setRepayment_Mode(String Repayment_Mode) {
        this.Repayment_Mode = Repayment_Mode;
    }

    public String getProp_Id_Type() {
        return Prop_Id_Type;
    }

    public void setProp_Id_Type(String Prop_Id_Type) {
        this.Prop_Id_Type = Prop_Id_Type;
    }

    public String getProp_Processing_Fee() {
        return Prop_Processing_Fee;
    }

    public void setProp_Processing_Fee(String Prop_Processing_Fee) {
        this.Prop_Processing_Fee = Prop_Processing_Fee;
    }

    public String getCheque_No() {
        return Cheque_No;
    }

    public void setCheque_No(String Cheque_No) {
        this.Cheque_No = Cheque_No;
    }

    public String getCheque_Date() {
        return Cheque_Date;
    }

    public void setCheque_Date(String Cheque_Date) {
        this.Cheque_Date = Cheque_Date;
    }

    public String getDrawn_On() {
        return Drawn_On;
    }

    public void setDrawn_On(String Drawn_On) {
        this.Drawn_On = Drawn_On;
    }

    public String getLoan_Cost() {
        return Loan_Cost;
    }

    public void setLoan_Cost(String Loan_Cost) {
        this.Loan_Cost = Loan_Cost;
    }

    public String getPurchase_Price() {
        return Purchase_Price;
    }

    public void setPurchase_Price(String Purchase_Price) {
        this.Purchase_Price = Purchase_Price;
    }

    public String getAmenities() {
        return Amenities;
    }

    public void setAmenities(String Amenities) {
        this.Amenities = Amenities;
    }

    public String getOther_Cost() {
        return Other_Cost;
    }

    public void setOther_Cost(String Other_Cost) {
        this.Other_Cost = Other_Cost;
    }

    public String getOwn_contri_Paid() {
        return Own_contri_Paid;
    }

    public void setOwn_contri_Paid(String Own_contri_Paid) {
        this.Own_contri_Paid = Own_contri_Paid;
    }

    public String getOwn_contri_Payable() {
        return Own_contri_Payable;
    }

    public void setOwn_contri_Payable(String Own_contri_Payable) {
        this.Own_contri_Payable = Own_contri_Payable;
    }

    public String getPersonal_Loan_Other() {
        return Personal_Loan_Other;
    }

    public void setPersonal_Loan_Other(String Personal_Loan_Other) {
        this.Personal_Loan_Other = Personal_Loan_Other;
    }

    public String getLoan_Requested() {
        return Loan_Requested;
    }

    public void setLoan_Requested(String Loan_Requested) {
        this.Loan_Requested = Loan_Requested;
    }

    public String getTrans_type() {
        return Trans_type;
    }

    public void setTrans_type(String Trans_type) {
        this.Trans_type = Trans_type;
    }

    public String getConstruction_stage() {
        return Construction_stage;
    }

    public void setConstruction_stage(String Construction_stage) {
        this.Construction_stage = Construction_stage;
    }

    public String getExpected_Completion() {
        return expected_Completion;
    }

    public void setExpected_Completion(String expected_Completion) {
        this.expected_Completion = expected_Completion;
    }

    public String getLand_area() {
        return Land_area;
    }

    public void setLand_area(String Land_area) {
        this.Land_area = Land_area;
    }

    public String getBuilt_up_area() {
        return Built_up_area;
    }

    public void setBuilt_up_area(String Built_up_area) {
        this.Built_up_area = Built_up_area;
    }

    public String getProp_Ownership_Name() {
        return Prop_Ownership_Name;
    }

    public void setProp_Ownership_Name(String Prop_Ownership_Name) {
        this.Prop_Ownership_Name = Prop_Ownership_Name;
    }

    public String getProp_type() {
        return Prop_type;
    }

    public void setProp_type(String Prop_type) {
        this.Prop_type = Prop_type;
    }

    public String getProp_Age() {
        return Prop_Age;
    }

    public void setProp_Age(String Prop_Age) {
        this.Prop_Age = Prop_Age;
    }

    public String getProp_Use() {
        return Prop_Use;
    }

    public void setProp_Use(String Prop_Use) {
        this.Prop_Use = Prop_Use;
    }

    public String getExpect_Month_rent() {
        return Expect_Month_rent;
    }

    public void setExpect_Month_rent(String Expect_Month_rent) {
        this.Expect_Month_rent = Expect_Month_rent;
    }

    public String getProp_Address1() {
        return Prop_Address1;
    }

    public void setProp_Address1(String Prop_Address1) {
        this.Prop_Address1 = Prop_Address1;
    }

    public String getProp_Address2() {
        return Prop_Address2;
    }

    public void setProp_Address2(String Prop_Address2) {
        this.Prop_Address2 = Prop_Address2;
    }

    public String getProp_Address3() {
        return Prop_Address3;
    }

    public void setProp_Address3(String Prop_Address3) {
        this.Prop_Address3 = Prop_Address3;
    }

    public String getProp_Landmark() {
        return Prop_Landmark;
    }

    public void setProp_Landmark(String Prop_Landmark) {
        this.Prop_Landmark = Prop_Landmark;
    }

    public String getProp_Pincode() {
        return Prop_Pincode;
    }

    public void setProp_Pincode(String Prop_Pincode) {
        this.Prop_Pincode = Prop_Pincode;
    }

    public String getProp_City() {
        return Prop_City;
    }

    public void setProp_City(String Prop_City) {
        this.Prop_City = Prop_City;
    }

    public String getProp_State() {
        return Prop_State;
    }

    public void setProp_State(String Prop_State) {
        this.Prop_State = Prop_State;
    }

    public String getProp_County() {
        return Prop_County;
    }

    public void setProp_County(String Prop_County) {
        this.Prop_County = Prop_County;
    }

    public String getMsc_Ref1_Name() {
        return Msc_Ref1_Name;
    }

    public void setMsc_Ref1_Name(String Msc_Ref1_Name) {
        this.Msc_Ref1_Name = Msc_Ref1_Name;
    }

    public String getMsc_Ref1_Pin_code() {
        return Msc_Ref1_Pin_code;
    }

    public void setMsc_Ref1_Pin_code(String Msc_Ref1_Pin_code) {
        this.Msc_Ref1_Pin_code = Msc_Ref1_Pin_code;
    }

    public String getMsc_Ref1_Landline_No() {
        return Msc_Ref1_Landline_No;
    }

    public void setMsc_Ref1_Landline_No(String Msc_Ref1_Landline_No) {
        this.Msc_Ref1_Landline_No = Msc_Ref1_Landline_No;
    }

    public String getMsc_Ref1_Mob_No() {
        return Msc_Ref1_Mob_No;
    }

    public void setMsc_Ref1_Mob_No(String Msc_Ref1_Mob_No) {
        this.Msc_Ref1_Mob_No = Msc_Ref1_Mob_No;
    }

    public String getMsc_Ref2_Name() {
        return Msc_Ref2_Name;
    }

    public void setMsc_Ref2_Name(String Msc_Ref2_Name) {
        this.Msc_Ref2_Name = Msc_Ref2_Name;
    }

    public String getMsc_Ref2_Pin_code() {
        return Msc_Ref2_Pin_code;
    }

    public void setMsc_Ref2_Pin_code(String Msc_Ref2_Pin_code) {
        this.Msc_Ref2_Pin_code = Msc_Ref2_Pin_code;
    }

    public String getMsc_Ref2_Landline_No() {
        return Msc_Ref2_Landline_No;
    }

    public void setMsc_Ref2_Landline_No(String Msc_Ref2_Landline_No) {
        this.Msc_Ref2_Landline_No = Msc_Ref2_Landline_No;
    }

    public String getMsc_Ref2_Mob_No() {
        return Msc_Ref2_Mob_No;
    }

    public void setMsc_Ref2_Mob_No(String Msc_Ref2_Mob_No) {
        this.Msc_Ref2_Mob_No = Msc_Ref2_Mob_No;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getDatetime_Created() {
        return Datetime_Created;
    }

    public void setDatetime_Created(String Datetime_Created) {
        this.Datetime_Created = Datetime_Created;
    }

    public String getIp_Address() {
        return Ip_Address;
    }

    public void setIp_Address(String Ip_Address) {
        this.Ip_Address = Ip_Address;
    }

    public String getUserId() {
        return UserId;
    }

    public void setUserId(String UserId) {
        this.UserId = UserId;
    }

    public String getLandlineNo_StdCode() {
        return LandlineNo_StdCode;
    }

    public void setLandlineNo_StdCode(String LandlineNo_StdCode) {
        this.LandlineNo_StdCode = LandlineNo_StdCode;
    }

    public String getPer_LandlineNo_StdCode() {
        return Per_LandlineNo_StdCode;
    }

    public void setPer_LandlineNo_StdCode(String Per_LandlineNo_StdCode) {
        this.Per_LandlineNo_StdCode = Per_LandlineNo_StdCode;
    }

    public String getOrganize_LandlineNo_StdCode() {
        return Organize_LandlineNo_StdCode;
    }

    public void setOrganize_LandlineNo_StdCode(String Organize_LandlineNo_StdCode) {
        this.Organize_LandlineNo_StdCode = Organize_LandlineNo_StdCode;
    }

    public String getCo_LandlineNo_StdCode() {
        return Co_LandlineNo_StdCode;
    }

    public void setCo_LandlineNo_StdCode(String Co_LandlineNo_StdCode) {
        this.Co_LandlineNo_StdCode = Co_LandlineNo_StdCode;
    }

    public String getCo_Per_LandlineNo_StdCode() {
        return Co_Per_LandlineNo_StdCode;
    }

    public void setCo_Per_LandlineNo_StdCode(String Co_Per_LandlineNo_StdCode) {
        this.Co_Per_LandlineNo_StdCode = Co_Per_LandlineNo_StdCode;
    }

    public String getCo_Organize_LandlineNo_StdCode() {
        return Co_Organize_LandlineNo_StdCode;
    }

    public void setCo_Organize_LandlineNo_StdCode(String Co_Organize_LandlineNo_StdCode) {
        this.Co_Organize_LandlineNo_StdCode = Co_Organize_LandlineNo_StdCode;
    }

    public String getMsc_Ref1_LandlineNo_StdCode() {
        return Msc_Ref1_LandlineNo_StdCode;
    }

    public void setMsc_Ref1_LandlineNo_StdCode(String Msc_Ref1_LandlineNo_StdCode) {
        this.Msc_Ref1_LandlineNo_StdCode = Msc_Ref1_LandlineNo_StdCode;
    }

    public String getMsc_Ref2_LandlineNo_StdCode() {
        return Msc_Ref2_LandlineNo_StdCode;
    }

    public void setMsc_Ref2_LandlineNo_StdCode(String Msc_Ref2_LandlineNo_StdCode) {
        this.Msc_Ref2_LandlineNo_StdCode = Msc_Ref2_LandlineNo_StdCode;
    }

    public int getBankId() {
        return BankId;
    }

    public void setBankId(int BankId) {
        this.BankId = BankId;
    }

    public int getBrokerId() {
        return BrokerId;
    }

    public void setBrokerId(int BrokerId) {
        this.BrokerId = BrokerId;
    }

    public int getIs_ApplnComplete() {
        return Is_ApplnComplete;
    }

    public void setIs_ApplnComplete(int Is_ApplnComplete) {
        this.Is_ApplnComplete = Is_ApplnComplete;
    }

    public int getProductId() {
        return ProductId;
    }

    public void setProductId(int ProductId) {
        this.ProductId = ProductId;
    }

    public int getIs_Confirm() {
        return Is_Confirm;
    }

    public void setIs_Confirm(int Is_Confirm) {
        this.Is_Confirm = Is_Confirm;
    }

    public int getIsCoApp() {
        return IsCoApp;
    }

    public void setIsCoApp(int IsCoApp) {
        this.IsCoApp = IsCoApp;
    }

    public String getTurn_Over() {
        return Turn_Over;
    }

    public void setTurn_Over(String Turn_Over) {
        this.Turn_Over = Turn_Over;
    }

    public String getDepreciation() {
        return Depreciation;
    }

    public void setDepreciation(String Depreciation) {
        this.Depreciation = Depreciation;
    }

    public String getDirector_Remuneration() {
        return Director_Remuneration;
    }

    public void setDirector_Remuneration(String Director_Remuneration) {
        this.Director_Remuneration = Director_Remuneration;
    }

    public String getProfit_Aft_Tax() {
        return Profit_Aft_Tax;
    }

    public void setProfit_Aft_Tax(String Profit_Aft_Tax) {
        this.Profit_Aft_Tax = Profit_Aft_Tax;
    }

    public String getCo_Turn_Over() {
        return Co_Turn_Over;
    }

    public void setCo_Turn_Over(String Co_Turn_Over) {
        this.Co_Turn_Over = Co_Turn_Over;
    }

    public String getCo_Depreciation() {
        return Co_Depreciation;
    }

    public void setCo_Depreciation(String Co_Depreciation) {
        this.Co_Depreciation = Co_Depreciation;
    }

    public String getCo_Director_Remuneration() {
        return Co_Director_Remuneration;
    }

    public void setCo_Director_Remuneration(String Co_Director_Remuneration) {
        this.Co_Director_Remuneration = Co_Director_Remuneration;
    }

    public String getCo_Profit_Aft_Tax() {
        return Co_Profit_Aft_Tax;
    }

    public void setCo_Profit_Aft_Tax(String Co_Profit_Aft_Tax) {
        this.Co_Profit_Aft_Tax = Co_Profit_Aft_Tax;
    }

    public String getFBA_Reg_Id() {
        return FBA_Reg_Id;
    }

    public void setFBA_Reg_Id(String FBA_Reg_Id) {
        this.FBA_Reg_Id = FBA_Reg_Id;
    }

    public String getAppln_Source() {
        return Appln_Source;
    }

    public void setAppln_Source(String Appln_Source) {
        this.Appln_Source = Appln_Source;
    }

    public String getSourcelink() {
        return sourcelink;
    }

    public void setSourcelink(String sourcelink) {
        this.sourcelink = sourcelink;
    }

    public String getCampaignName() {
        return CampaignName;
    }

    public void setCampaignName(String CampaignName) {
        this.CampaignName = CampaignName;
    }

    public String getDc_fba_reg() {
        return dc_fba_reg;
    }

    public void setDc_fba_reg(String dc_fba_reg) {
        this.dc_fba_reg = dc_fba_reg;
    }

    public String getRBA_Source() {
        return RBA_Source;
    }

    public void setRBA_Source(String RBA_Source) {
        this.RBA_Source = RBA_Source;
    }
}
