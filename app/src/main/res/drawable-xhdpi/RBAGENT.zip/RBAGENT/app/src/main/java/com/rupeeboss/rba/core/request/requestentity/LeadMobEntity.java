package com.rupeeboss.rba.core.request.requestentity;

public  class LeadMobEntity {
        /**
         * mobNo : 9820535509
         * leadId : 16872
         */

        private String mobNo;
        private String leadId;

        public String getMobNo() {
            return mobNo;
        }

        public void setMobNo(String mobNo) {
            this.mobNo = mobNo;
        }

        public String getLeadId() {
            return leadId;
        }

        public void setLeadId(String leadId) {
            this.leadId = leadId;
        }
    }