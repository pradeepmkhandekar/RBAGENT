package com.rupeeboss.rba.core.response;

import com.rupeeboss.rba.core.APIResponse;

/**
 * Created by Rajeev Ranjan on 27/02/2017.
 */

public class SendSmsMobileResponse extends APIResponse {

}
