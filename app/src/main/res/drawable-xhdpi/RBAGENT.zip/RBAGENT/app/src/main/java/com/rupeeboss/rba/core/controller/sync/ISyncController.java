package com.rupeeboss.rba.core.controller.sync;

import com.rupeeboss.rba.core.IResponseSubcriber;

/**
 * Created by Nilesh Birhade on 23-01-2017.
 */

public interface ISyncController {

    void getCity();

    void getProducts();

    void getProperty();
}
