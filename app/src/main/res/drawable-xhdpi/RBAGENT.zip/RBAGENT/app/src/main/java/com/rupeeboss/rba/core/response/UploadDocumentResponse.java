package com.rupeeboss.rba.core.response;

import com.rupeeboss.rba.core.APIResponse;

/**
 * Created by IN-RB on 21-08-2017.
 */

public class UploadDocumentResponse extends APIResponse {


    /**
     * resultbytes : null
     */

    private String resultbytes;

    public String getResultbytes() {
        return resultbytes;
    }

    public void setResultbytes(String resultbytes) {
        this.resultbytes = resultbytes;
    }
}
