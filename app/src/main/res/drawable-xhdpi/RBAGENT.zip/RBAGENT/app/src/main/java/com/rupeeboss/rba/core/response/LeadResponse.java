package com.rupeeboss.rba.core.response;

import com.rupeeboss.rba.core.APIResponse;

/**
 * Created by Rajeev Ranjan on 14/11/2016.
 */

public class LeadResponse extends APIResponse {

    /**
     * result : null
     */

    private Object result;

    public Object getResult() {
        return result;
    }

    public void setResult(Object result) {
        this.result = result;
    }
}
