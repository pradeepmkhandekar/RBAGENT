package com.rupeeboss.rba.core.response;

import com.rupeeboss.rba.core.APIResponse;

/**
 * Created by IN-RB on 21-08-2017.
 */

public class ChangePasseordResponse extends APIResponse {
}
