package com.rupeeboss.rba.core.model;

public  class EmiCalcuatorEntity {
        /**
         * amount : 103781
         * total : 18905
         * ttl_payment : 518905
         */

        private double amount;
        private double total;
        private double ttl_payment;

        public double getAmount() {
            return amount;
        }

        public void setAmount(double amount) {
            this.amount = amount;
        }

        public double getTotal() {
            return total;
        }

        public void setTotal(double total) {
            this.total = total;
        }

        public double getTtl_payment() {
            return ttl_payment;
        }

        public void setTtl_payment(double ttl_payment) {
            this.ttl_payment = ttl_payment;
        }
    }