package com.rupeeboss.rba.core_loan_fm.requestentity;

public  class equifax {
        /**
         * name : www.rupeeboss.com/uploads/PDF/Hit_CEAPK5523G.pdf
         * score : 478
         */

        private String name;
        private String score;

        public String getName() {
            return name;
        }

        public void setName(String name) {
            this.name = name;
        }

        public String getScore() {
            return score;
        }

        public void setScore(String score) {
            this.score = score;
        }
    }