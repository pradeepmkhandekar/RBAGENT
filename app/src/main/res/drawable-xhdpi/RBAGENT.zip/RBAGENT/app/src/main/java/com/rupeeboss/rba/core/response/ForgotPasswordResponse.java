package com.rupeeboss.rba.core.response;

import com.rupeeboss.rba.core.APIResponse;

/**
 * Created by Sameer Naik on 12-11-2016.
 */

public class ForgotPasswordResponse extends APIResponse {


}
