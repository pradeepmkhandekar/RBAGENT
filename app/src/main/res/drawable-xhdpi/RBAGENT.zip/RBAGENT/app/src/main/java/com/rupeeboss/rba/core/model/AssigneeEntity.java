package com.rupeeboss.rba.core.model;

public class AssigneeEntity {
    /**
     * assigneeId : 190
     * assigneeName : Rakesh Azad Yadav
     */

    private int assigneeId;
    private String assigneeName;

    public int getAssigneeId() {
        return assigneeId;
    }

    public void setAssigneeId(int assigneeId) {
        this.assigneeId = assigneeId;
    }

    public String getAssigneeName() {
        return assigneeName;
    }

    public void setAssigneeName(String assigneeName) {
        this.assigneeName = assigneeName;
    }
}