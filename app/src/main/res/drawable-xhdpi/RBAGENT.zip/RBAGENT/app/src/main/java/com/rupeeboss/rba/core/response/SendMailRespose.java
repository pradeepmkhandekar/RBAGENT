package com.rupeeboss.rba.core.response;

import com.rupeeboss.rba.core.APIResponse;

/**
 * Created by IN-RB on 26-06-2017.
 */

public class SendMailRespose  extends APIResponse {
}
