package com.rupeeboss.rba.core.model;

public  class ProductsEntity {
    /**
     * prodId : 1
     * prodName : USED CAR Loan
     */

    private int prodId;
    private String prodName;

    public int getProdId() {
        return prodId;
    }

    public void setProdId(int prodId) {
        this.prodId = prodId;
    }

    public String getProdName() {
        return prodName;
    }

    public void setProdName(String prodName) {
        this.prodName = prodName;
    }
}