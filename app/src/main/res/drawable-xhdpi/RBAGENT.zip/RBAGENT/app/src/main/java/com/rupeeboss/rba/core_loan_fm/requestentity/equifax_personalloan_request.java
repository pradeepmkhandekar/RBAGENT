package com.rupeeboss.rba.core_loan_fm.requestentity;

/**
 * Created by IN-RB on 18-09-2018.
 */

public class equifax_personalloan_request {
    /**
     * FirstName : Praveen
     * MiddleName : Padmarao
     * LastName : Jangam
     * MobilePhone : 7506010213
     * DOB : 1991-12-03
     * PANId : CEAPK5523G
     * MaritalStatus : single
     * Gender : 1
     * AddressLine : Nav Bharat Seva Sangh,Hanuman Tekdi,Gate No 1,R.No A/79,Santacruz East
     * AddressType : C
     * State : MH
     * City : MUMBAI
     * Locality1 : Near Regency Hotel
     * Postal : 400055
     * PhoneType : M
     * AccountNumber :
     */

    private String FirstName;
    private String MiddleName;
    private String LastName;
    private String MobilePhone;
    private String DOB;
    private String PANId;
    private String MaritalStatus;
    private String Gender;
    private String AddressLine;
    private String AddressType;
    private String State;
    private String City;
    private String Locality1;
    private String Postal;
    private String PhoneType;
    private String AccountNumber;

    public String getFirstName() {
        return FirstName;
    }

    public void setFirstName(String FirstName) {
        this.FirstName = FirstName;
    }

    public String getMiddleName() {
        return MiddleName;
    }

    public void setMiddleName(String MiddleName) {
        this.MiddleName = MiddleName;
    }

    public String getLastName() {
        return LastName;
    }

    public void setLastName(String LastName) {
        this.LastName = LastName;
    }

    public String getMobilePhone() {
        return MobilePhone;
    }

    public void setMobilePhone(String MobilePhone) {
        this.MobilePhone = MobilePhone;
    }

    public String getDOB() {
        return DOB;
    }

    public void setDOB(String DOB) {
        this.DOB = DOB;
    }

    public String getPANId() {
        return PANId;
    }

    public void setPANId(String PANId) {
        this.PANId = PANId;
    }

    public String getMaritalStatus() {
        return MaritalStatus;
    }

    public void setMaritalStatus(String MaritalStatus) {
        this.MaritalStatus = MaritalStatus;
    }

    public String getGender() {
        return Gender;
    }

    public void setGender(String Gender) {
        this.Gender = Gender;
    }

    public String getAddressLine() {
        return AddressLine;
    }

    public void setAddressLine(String AddressLine) {
        this.AddressLine = AddressLine;
    }

    public String getAddressType() {
        return AddressType;
    }

    public void setAddressType(String AddressType) {
        this.AddressType = AddressType;
    }

    public String getState() {
        return State;
    }

    public void setState(String State) {
        this.State = State;
    }

    public String getCity() {
        return City;
    }

    public void setCity(String City) {
        this.City = City;
    }

    public String getLocality1() {
        return Locality1;
    }

    public void setLocality1(String Locality1) {
        this.Locality1 = Locality1;
    }

    public String getPostal() {
        return Postal;
    }

    public void setPostal(String Postal) {
        this.Postal = Postal;
    }

    public String getPhoneType() {
        return PhoneType;
    }

    public void setPhoneType(String PhoneType) {
        this.PhoneType = PhoneType;
    }

    public String getAccountNumber() {
        return AccountNumber;
    }

    public void setAccountNumber(String AccountNumber) {
        this.AccountNumber = AccountNumber;
    }
}
