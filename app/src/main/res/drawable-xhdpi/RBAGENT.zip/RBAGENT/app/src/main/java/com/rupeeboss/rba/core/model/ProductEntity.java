package com.rupeeboss.rba.core.model;

public class ProductEntity {
        /**
         * Product_Id : 1
         * Product_Name : USED CAR Loan
         */

        private int Product_Id;
        private String Product_Name;

        public int getProduct_Id() {
            return Product_Id;
        }

        public void setProduct_Id(int Product_Id) {
            this.Product_Id = Product_Id;
        }

        public String getProduct_Name() {
            return Product_Name;
        }

        public void setProduct_Name(String Product_Name) {
            this.Product_Name = Product_Name;
        }
    }
