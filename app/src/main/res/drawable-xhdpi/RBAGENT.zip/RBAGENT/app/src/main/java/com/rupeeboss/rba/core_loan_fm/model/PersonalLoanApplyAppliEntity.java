package com.rupeeboss.rba.core_loan_fm.model;

/**
 * Created by IN-RB on 16-03-2018.
 */

public class PersonalLoanApplyAppliEntity {


    /**
     * ApplnId : 0
     * Level :
     * Residence_Type :
     * Quote_id : 10
     * empCode :
     * Title : MR
     * First_Name : test Sneha
     * Middle_Name : w
     * Last_Name : w
     * Marital_Status : Married
     * Spouce_Name : test
     * Mother_Name :
     * Category_Id :
     * No_Of_Dependent :
     * PAN_No :
     * Passport_No :
     * Driving_Lic_No :
     * Aadhar_Card_No :
     * Voters_Id :
     * DOB :
     * Status_Id :
     * Gender :
     * Nationality :
     * Id_Type :
     * Id_No :
     * Institute_University :
     * Mothers_Maidan_Name :
     * Education_Id :
     * Mobile_No1 :
     * Mobile_No2 :
     * Per_Email_Id :
     * Ofc_Email_Id :
     * Co_Ofc_Email_Id :
     * Address1 :
     * Address2 :
     * Address3 :
     * Landmark :
     * Pincode :
     * City :
     * State :
     * Country :
     * LandlineNo :
     * AddrsYrs :
     * Per_Address1 :
     * Per_Address2 :
     * Per_Address3 :
     * Per_Landmark :
     * Per_Pincode :
     * Per_City :
     * Per_State :
     * Per_Country :
     * Per_LandlineNo :
     * Per_AddrsYrs :
     * Nature_Of_Employer :
     * Nature_Of_Organization :
     * Nature_Of_Business :
     * Designation :
     * Currnet_Employment_Period :
     * Total_Employment_Period :
     * Name_of_Organisation :
     * Address1_of_Organisation :
     * Address2_of_Organisation :
     * Address3_of_Organisation :
     * Organize_Landmark :
     * Organize_Pincode :
     * Organize_City :
     * Organize_State :
     * Organize_Country :
     * Organize_LandlineNo :
     * Gross_Income :
     * Net_Income :
     * Other_Income :
     * Total_Income :
     * IFSC_Code_Bank1 :
     * Bank1_Name :
     * Bank1_AcctType :
     * Bank1_AcctNo :
     * IFSC_Code_Bank2 :
     * Bank2_Name :
     * Bank2_AcctType :
     * Bank2_AcctNo :
     * Bank_Loan1 :
     * Type_Loan1 :
     * Amnt_Loan1 :
     * EMI_Loan1 :
     * Bank_Loan2 :
     * Type_Loan2 :
     * Amnt_Loan2 :
     * EMI_Loan2 :
     * Vehicle_Type :
     * MakenModel_Vehicle :
     * Dt_Purchase :
     * Hypo_To :
     * Vehicle_Type2 :
     * MakenModel_Vehicle2 :
     * Dt_Purchase2 :
     * Hypo_To2 :
     * Msc_Ref1_Name :
     * Msc_Ref1_Pin_code :
     * Msc_Ref1_Landline_No :
     * Msc_Ref1_Mob_No :
     * Msc_Ref2_Name :
     * Msc_Ref2_Pin_code :
     * Msc_Ref2_Landline_No :
     * Msc_Ref2_Mob_No :
     * Datetime_Created :
     * Ip_Address :
     * UserId :
     * LandlineNo_StdCode :
     * Per_LandlineNo_StdCode :
     * Organize_LandlineNo_StdCode :
     * Msc_Ref1_LandlineNo_StdCode :
     * Msc_Ref2_LandlineNo_StdCode :
     * BankId : 0
     * BrokerId : 0
     * Is_ApplnComplete : 0
     * ProductId : 0
     * Is_Confirm : 0
     * Turn_Over :
     * Depreciation :
     * Director_Remuneration :
     * Profit_Aft_Tax :
     * FBA_Reg_Id :
     * Loan_Amount :
     * ROI_Id_Type :
     * Processing_Fee :
     * Loan_Terms :
     * Appln_Source :
     * sourcelink :
     * CampaignName :
     * dc_fba_reg :
     * RBA_Source :
     */

    private int ApplnId;
    private String Level;
    private String Residence_Type;
    private int Quote_id;
    private String empCode;
    private String Title;
    private String First_Name;
    private String Middle_Name;
    private String Last_Name;
    private String Marital_Status;
    private String Spouce_Name;
    private String Mother_Name;
    private String Category_Id;
    private String No_Of_Dependent;
    private String PAN_No;
    private String Passport_No;
    private String Driving_Lic_No;
    private String Aadhar_Card_No;
    private String Voters_Id;
    private String DOB;
    private String Status_Id;
    private String Gender;
    private String Nationality;
    private String Id_Type;
    private String Id_No;
    private String Institute_University;
    private String Mothers_Maidan_Name;
    private String Education_Id;
    private String Mobile_No1;
    private String Mobile_No2;
    private String Per_Email_Id;
    private String Ofc_Email_Id;
    private String Co_Ofc_Email_Id;
    private String Address1;
    private String Address2;
    private String Address3;
    private String Landmark;
    private String Pincode;
    private String City;
    private String State;
    private String Country;
    private String LandlineNo;
    private String AddrsYrs;
    private String Per_Address1;
    private String Per_Address2;
    private String Per_Address3;
    private String Per_Landmark;
    private String Per_Pincode;
    private String Per_City;
    private String Per_State;
    private String Per_Country;
    private String Per_LandlineNo;
    private String Per_AddrsYrs;
    private String Nature_Of_Employer;
    private String Nature_Of_Organization;
    private String Nature_Of_Business;
    private String Designation;
    private String Currnet_Employment_Period;
    private String Total_Employment_Period;
    private String Name_of_Organisation;
    private String Address1_of_Organisation;
    private String Address2_of_Organisation;
    private String Address3_of_Organisation;
    private String Organize_Landmark;
    private String Organize_Pincode;
    private String Organize_City;
    private String Organize_State;
    private String Organize_Country;
    private String Organize_LandlineNo;
    private String Gross_Income;
    private String Net_Income;
    private String Other_Income;
    private String Total_Income;
    private String IFSC_Code_Bank1;
    private String Bank1_Name;
    private String Bank1_AcctType;
    private String Bank1_AcctNo;
    private String IFSC_Code_Bank2;
    private String Bank2_Name;
    private String Bank2_AcctType;
    private String Bank2_AcctNo;
    private String Bank_Loan1;
    private String Type_Loan1;
    private String Amnt_Loan1;
    private String EMI_Loan1;
    private String Bank_Loan2;
    private String Type_Loan2;
    private String Amnt_Loan2;
    private String EMI_Loan2;
    private String Vehicle_Type;
    private String MakenModel_Vehicle;
    private String Dt_Purchase;
    private String Hypo_To;
    private String Vehicle_Type2;
    private String MakenModel_Vehicle2;
    private String Dt_Purchase2;
    private String Hypo_To2;
    private String Msc_Ref1_Name;
    private String Msc_Ref1_Pin_code;
    private String Msc_Ref1_Landline_No;
    private String Msc_Ref1_Mob_No;
    private String Msc_Ref2_Name;
    private String Msc_Ref2_Pin_code;
    private String Msc_Ref2_Landline_No;
    private String Msc_Ref2_Mob_No;
    private String Datetime_Created;
    private String Ip_Address;
    private String UserId;
    private String LandlineNo_StdCode;
    private String Per_LandlineNo_StdCode;
    private String Organize_LandlineNo_StdCode;
    private String Msc_Ref1_LandlineNo_StdCode;
    private String Msc_Ref2_LandlineNo_StdCode;
    private int BankId;
    private int BrokerId;
    private int Is_ApplnComplete;
    private int ProductId;
    private int Is_Confirm;
    private String Turn_Over;
    private String Depreciation;
    private String Director_Remuneration;
    private String Profit_Aft_Tax;
    private String FBA_Reg_Id;
    private String Loan_Amount;
    private String ROI_Id_Type;
    private String Processing_Fee;
    private String Loan_Terms;
    private String Appln_Source;
    private String sourcelink;
    private String CampaignName;
    private String dc_fba_reg;
    private String RBA_Source;

    public int getApplnId() {
        return ApplnId;
    }

    public void setApplnId(int ApplnId) {
        this.ApplnId = ApplnId;
    }

    public String getLevel() {
        return Level;
    }

    public void setLevel(String Level) {
        this.Level = Level;
    }

    public String getResidence_Type() {
        return Residence_Type;
    }

    public void setResidence_Type(String Residence_Type) {
        this.Residence_Type = Residence_Type;
    }

    public int getQuote_id() {
        return Quote_id;
    }

    public void setQuote_id(int Quote_id) {
        this.Quote_id = Quote_id;
    }

    public String getEmpCode() {
        return empCode;
    }

    public void setEmpCode(String empCode) {
        this.empCode = empCode;
    }

    public String getTitle() {
        return Title;
    }

    public void setTitle(String Title) {
        this.Title = Title;
    }

    public String getFirst_Name() {
        return First_Name;
    }

    public void setFirst_Name(String First_Name) {
        this.First_Name = First_Name;
    }

    public String getMiddle_Name() {
        return Middle_Name;
    }

    public void setMiddle_Name(String Middle_Name) {
        this.Middle_Name = Middle_Name;
    }

    public String getLast_Name() {
        return Last_Name;
    }

    public void setLast_Name(String Last_Name) {
        this.Last_Name = Last_Name;
    }

    public String getMarital_Status() {
        return Marital_Status;
    }

    public void setMarital_Status(String Marital_Status) {
        this.Marital_Status = Marital_Status;
    }

    public String getSpouce_Name() {
        return Spouce_Name;
    }

    public void setSpouce_Name(String Spouce_Name) {
        this.Spouce_Name = Spouce_Name;
    }

    public String getMother_Name() {
        return Mother_Name;
    }

    public void setMother_Name(String Mother_Name) {
        this.Mother_Name = Mother_Name;
    }

    public String getCategory_Id() {
        return Category_Id;
    }

    public void setCategory_Id(String Category_Id) {
        this.Category_Id = Category_Id;
    }

    public String getNo_Of_Dependent() {
        return No_Of_Dependent;
    }

    public void setNo_Of_Dependent(String No_Of_Dependent) {
        this.No_Of_Dependent = No_Of_Dependent;
    }

    public String getPAN_No() {
        return PAN_No;
    }

    public void setPAN_No(String PAN_No) {
        this.PAN_No = PAN_No;
    }

    public String getPassport_No() {
        return Passport_No;
    }

    public void setPassport_No(String Passport_No) {
        this.Passport_No = Passport_No;
    }

    public String getDriving_Lic_No() {
        return Driving_Lic_No;
    }

    public void setDriving_Lic_No(String Driving_Lic_No) {
        this.Driving_Lic_No = Driving_Lic_No;
    }

    public String getAadhar_Card_No() {
        return Aadhar_Card_No;
    }

    public void setAadhar_Card_No(String Aadhar_Card_No) {
        this.Aadhar_Card_No = Aadhar_Card_No;
    }

    public String getVoters_Id() {
        return Voters_Id;
    }

    public void setVoters_Id(String Voters_Id) {
        this.Voters_Id = Voters_Id;
    }

    public String getDOB() {
        return DOB;
    }

    public void setDOB(String DOB) {
        this.DOB = DOB;
    }

    public String getStatus_Id() {
        return Status_Id;
    }

    public void setStatus_Id(String Status_Id) {
        this.Status_Id = Status_Id;
    }

    public String getGender() {
        return Gender;
    }

    public void setGender(String Gender) {
        this.Gender = Gender;
    }

    public String getNationality() {
        return Nationality;
    }

    public void setNationality(String Nationality) {
        this.Nationality = Nationality;
    }

    public String getId_Type() {
        return Id_Type;
    }

    public void setId_Type(String Id_Type) {
        this.Id_Type = Id_Type;
    }

    public String getId_No() {
        return Id_No;
    }

    public void setId_No(String Id_No) {
        this.Id_No = Id_No;
    }

    public String getInstitute_University() {
        return Institute_University;
    }

    public void setInstitute_University(String Institute_University) {
        this.Institute_University = Institute_University;
    }

    public String getMothers_Maidan_Name() {
        return Mothers_Maidan_Name;
    }

    public void setMothers_Maidan_Name(String Mothers_Maidan_Name) {
        this.Mothers_Maidan_Name = Mothers_Maidan_Name;
    }

    public String getEducation_Id() {
        return Education_Id;
    }

    public void setEducation_Id(String Education_Id) {
        this.Education_Id = Education_Id;
    }

    public String getMobile_No1() {
        return Mobile_No1;
    }

    public void setMobile_No1(String Mobile_No1) {
        this.Mobile_No1 = Mobile_No1;
    }

    public String getMobile_No2() {
        return Mobile_No2;
    }

    public void setMobile_No2(String Mobile_No2) {
        this.Mobile_No2 = Mobile_No2;
    }

    public String getPer_Email_Id() {
        return Per_Email_Id;
    }

    public void setPer_Email_Id(String Per_Email_Id) {
        this.Per_Email_Id = Per_Email_Id;
    }

    public String getOfc_Email_Id() {
        return Ofc_Email_Id;
    }

    public void setOfc_Email_Id(String Ofc_Email_Id) {
        this.Ofc_Email_Id = Ofc_Email_Id;
    }

    public String getCo_Ofc_Email_Id() {
        return Co_Ofc_Email_Id;
    }

    public void setCo_Ofc_Email_Id(String Co_Ofc_Email_Id) {
        this.Co_Ofc_Email_Id = Co_Ofc_Email_Id;
    }

    public String getAddress1() {
        return Address1;
    }

    public void setAddress1(String Address1) {
        this.Address1 = Address1;
    }

    public String getAddress2() {
        return Address2;
    }

    public void setAddress2(String Address2) {
        this.Address2 = Address2;
    }

    public String getAddress3() {
        return Address3;
    }

    public void setAddress3(String Address3) {
        this.Address3 = Address3;
    }

    public String getLandmark() {
        return Landmark;
    }

    public void setLandmark(String Landmark) {
        this.Landmark = Landmark;
    }

    public String getPincode() {
        return Pincode;
    }

    public void setPincode(String Pincode) {
        this.Pincode = Pincode;
    }

    public String getCity() {
        return City;
    }

    public void setCity(String City) {
        this.City = City;
    }

    public String getState() {
        return State;
    }

    public void setState(String State) {
        this.State = State;
    }

    public String getCountry() {
        return Country;
    }

    public void setCountry(String Country) {
        this.Country = Country;
    }

    public String getLandlineNo() {
        return LandlineNo;
    }

    public void setLandlineNo(String LandlineNo) {
        this.LandlineNo = LandlineNo;
    }

    public String getAddrsYrs() {
        return AddrsYrs;
    }

    public void setAddrsYrs(String AddrsYrs) {
        this.AddrsYrs = AddrsYrs;
    }

    public String getPer_Address1() {
        return Per_Address1;
    }

    public void setPer_Address1(String Per_Address1) {
        this.Per_Address1 = Per_Address1;
    }

    public String getPer_Address2() {
        return Per_Address2;
    }

    public void setPer_Address2(String Per_Address2) {
        this.Per_Address2 = Per_Address2;
    }

    public String getPer_Address3() {
        return Per_Address3;
    }

    public void setPer_Address3(String Per_Address3) {
        this.Per_Address3 = Per_Address3;
    }

    public String getPer_Landmark() {
        return Per_Landmark;
    }

    public void setPer_Landmark(String Per_Landmark) {
        this.Per_Landmark = Per_Landmark;
    }

    public String getPer_Pincode() {
        return Per_Pincode;
    }

    public void setPer_Pincode(String Per_Pincode) {
        this.Per_Pincode = Per_Pincode;
    }

    public String getPer_City() {
        return Per_City;
    }

    public void setPer_City(String Per_City) {
        this.Per_City = Per_City;
    }

    public String getPer_State() {
        return Per_State;
    }

    public void setPer_State(String Per_State) {
        this.Per_State = Per_State;
    }

    public String getPer_Country() {
        return Per_Country;
    }

    public void setPer_Country(String Per_Country) {
        this.Per_Country = Per_Country;
    }

    public String getPer_LandlineNo() {
        return Per_LandlineNo;
    }

    public void setPer_LandlineNo(String Per_LandlineNo) {
        this.Per_LandlineNo = Per_LandlineNo;
    }

    public String getPer_AddrsYrs() {
        return Per_AddrsYrs;
    }

    public void setPer_AddrsYrs(String Per_AddrsYrs) {
        this.Per_AddrsYrs = Per_AddrsYrs;
    }

    public String getNature_Of_Employer() {
        return Nature_Of_Employer;
    }

    public void setNature_Of_Employer(String Nature_Of_Employer) {
        this.Nature_Of_Employer = Nature_Of_Employer;
    }

    public String getNature_Of_Organization() {
        return Nature_Of_Organization;
    }

    public void setNature_Of_Organization(String Nature_Of_Organization) {
        this.Nature_Of_Organization = Nature_Of_Organization;
    }

    public String getNature_Of_Business() {
        return Nature_Of_Business;
    }

    public void setNature_Of_Business(String Nature_Of_Business) {
        this.Nature_Of_Business = Nature_Of_Business;
    }

    public String getDesignation() {
        return Designation;
    }

    public void setDesignation(String Designation) {
        this.Designation = Designation;
    }

    public String getCurrnet_Employment_Period() {
        return Currnet_Employment_Period;
    }

    public void setCurrnet_Employment_Period(String Currnet_Employment_Period) {
        this.Currnet_Employment_Period = Currnet_Employment_Period;
    }

    public String getTotal_Employment_Period() {
        return Total_Employment_Period;
    }

    public void setTotal_Employment_Period(String Total_Employment_Period) {
        this.Total_Employment_Period = Total_Employment_Period;
    }

    public String getName_of_Organisation() {
        return Name_of_Organisation;
    }

    public void setName_of_Organisation(String Name_of_Organisation) {
        this.Name_of_Organisation = Name_of_Organisation;
    }

    public String getAddress1_of_Organisation() {
        return Address1_of_Organisation;
    }

    public void setAddress1_of_Organisation(String Address1_of_Organisation) {
        this.Address1_of_Organisation = Address1_of_Organisation;
    }

    public String getAddress2_of_Organisation() {
        return Address2_of_Organisation;
    }

    public void setAddress2_of_Organisation(String Address2_of_Organisation) {
        this.Address2_of_Organisation = Address2_of_Organisation;
    }

    public String getAddress3_of_Organisation() {
        return Address3_of_Organisation;
    }

    public void setAddress3_of_Organisation(String Address3_of_Organisation) {
        this.Address3_of_Organisation = Address3_of_Organisation;
    }

    public String getOrganize_Landmark() {
        return Organize_Landmark;
    }

    public void setOrganize_Landmark(String Organize_Landmark) {
        this.Organize_Landmark = Organize_Landmark;
    }

    public String getOrganize_Pincode() {
        return Organize_Pincode;
    }

    public void setOrganize_Pincode(String Organize_Pincode) {
        this.Organize_Pincode = Organize_Pincode;
    }

    public String getOrganize_City() {
        return Organize_City;
    }

    public void setOrganize_City(String Organize_City) {
        this.Organize_City = Organize_City;
    }

    public String getOrganize_State() {
        return Organize_State;
    }

    public void setOrganize_State(String Organize_State) {
        this.Organize_State = Organize_State;
    }

    public String getOrganize_Country() {
        return Organize_Country;
    }

    public void setOrganize_Country(String Organize_Country) {
        this.Organize_Country = Organize_Country;
    }

    public String getOrganize_LandlineNo() {
        return Organize_LandlineNo;
    }

    public void setOrganize_LandlineNo(String Organize_LandlineNo) {
        this.Organize_LandlineNo = Organize_LandlineNo;
    }

    public String getGross_Income() {
        return Gross_Income;
    }

    public void setGross_Income(String Gross_Income) {
        this.Gross_Income = Gross_Income;
    }

    public String getNet_Income() {
        return Net_Income;
    }

    public void setNet_Income(String Net_Income) {
        this.Net_Income = Net_Income;
    }

    public String getOther_Income() {
        return Other_Income;
    }

    public void setOther_Income(String Other_Income) {
        this.Other_Income = Other_Income;
    }

    public String getTotal_Income() {
        return Total_Income;
    }

    public void setTotal_Income(String Total_Income) {
        this.Total_Income = Total_Income;
    }

    public String getIFSC_Code_Bank1() {
        return IFSC_Code_Bank1;
    }

    public void setIFSC_Code_Bank1(String IFSC_Code_Bank1) {
        this.IFSC_Code_Bank1 = IFSC_Code_Bank1;
    }

    public String getBank1_Name() {
        return Bank1_Name;
    }

    public void setBank1_Name(String Bank1_Name) {
        this.Bank1_Name = Bank1_Name;
    }

    public String getBank1_AcctType() {
        return Bank1_AcctType;
    }

    public void setBank1_AcctType(String Bank1_AcctType) {
        this.Bank1_AcctType = Bank1_AcctType;
    }

    public String getBank1_AcctNo() {
        return Bank1_AcctNo;
    }

    public void setBank1_AcctNo(String Bank1_AcctNo) {
        this.Bank1_AcctNo = Bank1_AcctNo;
    }

    public String getIFSC_Code_Bank2() {
        return IFSC_Code_Bank2;
    }

    public void setIFSC_Code_Bank2(String IFSC_Code_Bank2) {
        this.IFSC_Code_Bank2 = IFSC_Code_Bank2;
    }

    public String getBank2_Name() {
        return Bank2_Name;
    }

    public void setBank2_Name(String Bank2_Name) {
        this.Bank2_Name = Bank2_Name;
    }

    public String getBank2_AcctType() {
        return Bank2_AcctType;
    }

    public void setBank2_AcctType(String Bank2_AcctType) {
        this.Bank2_AcctType = Bank2_AcctType;
    }

    public String getBank2_AcctNo() {
        return Bank2_AcctNo;
    }

    public void setBank2_AcctNo(String Bank2_AcctNo) {
        this.Bank2_AcctNo = Bank2_AcctNo;
    }

    public String getBank_Loan1() {
        return Bank_Loan1;
    }

    public void setBank_Loan1(String Bank_Loan1) {
        this.Bank_Loan1 = Bank_Loan1;
    }

    public String getType_Loan1() {
        return Type_Loan1;
    }

    public void setType_Loan1(String Type_Loan1) {
        this.Type_Loan1 = Type_Loan1;
    }

    public String getAmnt_Loan1() {
        return Amnt_Loan1;
    }

    public void setAmnt_Loan1(String Amnt_Loan1) {
        this.Amnt_Loan1 = Amnt_Loan1;
    }

    public String getEMI_Loan1() {
        return EMI_Loan1;
    }

    public void setEMI_Loan1(String EMI_Loan1) {
        this.EMI_Loan1 = EMI_Loan1;
    }

    public String getBank_Loan2() {
        return Bank_Loan2;
    }

    public void setBank_Loan2(String Bank_Loan2) {
        this.Bank_Loan2 = Bank_Loan2;
    }

    public String getType_Loan2() {
        return Type_Loan2;
    }

    public void setType_Loan2(String Type_Loan2) {
        this.Type_Loan2 = Type_Loan2;
    }

    public String getAmnt_Loan2() {
        return Amnt_Loan2;
    }

    public void setAmnt_Loan2(String Amnt_Loan2) {
        this.Amnt_Loan2 = Amnt_Loan2;
    }

    public String getEMI_Loan2() {
        return EMI_Loan2;
    }

    public void setEMI_Loan2(String EMI_Loan2) {
        this.EMI_Loan2 = EMI_Loan2;
    }

    public String getVehicle_Type() {
        return Vehicle_Type;
    }

    public void setVehicle_Type(String Vehicle_Type) {
        this.Vehicle_Type = Vehicle_Type;
    }

    public String getMakenModel_Vehicle() {
        return MakenModel_Vehicle;
    }

    public void setMakenModel_Vehicle(String MakenModel_Vehicle) {
        this.MakenModel_Vehicle = MakenModel_Vehicle;
    }

    public String getDt_Purchase() {
        return Dt_Purchase;
    }

    public void setDt_Purchase(String Dt_Purchase) {
        this.Dt_Purchase = Dt_Purchase;
    }

    public String getHypo_To() {
        return Hypo_To;
    }

    public void setHypo_To(String Hypo_To) {
        this.Hypo_To = Hypo_To;
    }

    public String getVehicle_Type2() {
        return Vehicle_Type2;
    }

    public void setVehicle_Type2(String Vehicle_Type2) {
        this.Vehicle_Type2 = Vehicle_Type2;
    }

    public String getMakenModel_Vehicle2() {
        return MakenModel_Vehicle2;
    }

    public void setMakenModel_Vehicle2(String MakenModel_Vehicle2) {
        this.MakenModel_Vehicle2 = MakenModel_Vehicle2;
    }

    public String getDt_Purchase2() {
        return Dt_Purchase2;
    }

    public void setDt_Purchase2(String Dt_Purchase2) {
        this.Dt_Purchase2 = Dt_Purchase2;
    }

    public String getHypo_To2() {
        return Hypo_To2;
    }

    public void setHypo_To2(String Hypo_To2) {
        this.Hypo_To2 = Hypo_To2;
    }

    public String getMsc_Ref1_Name() {
        return Msc_Ref1_Name;
    }

    public void setMsc_Ref1_Name(String Msc_Ref1_Name) {
        this.Msc_Ref1_Name = Msc_Ref1_Name;
    }

    public String getMsc_Ref1_Pin_code() {
        return Msc_Ref1_Pin_code;
    }

    public void setMsc_Ref1_Pin_code(String Msc_Ref1_Pin_code) {
        this.Msc_Ref1_Pin_code = Msc_Ref1_Pin_code;
    }

    public String getMsc_Ref1_Landline_No() {
        return Msc_Ref1_Landline_No;
    }

    public void setMsc_Ref1_Landline_No(String Msc_Ref1_Landline_No) {
        this.Msc_Ref1_Landline_No = Msc_Ref1_Landline_No;
    }

    public String getMsc_Ref1_Mob_No() {
        return Msc_Ref1_Mob_No;
    }

    public void setMsc_Ref1_Mob_No(String Msc_Ref1_Mob_No) {
        this.Msc_Ref1_Mob_No = Msc_Ref1_Mob_No;
    }

    public String getMsc_Ref2_Name() {
        return Msc_Ref2_Name;
    }

    public void setMsc_Ref2_Name(String Msc_Ref2_Name) {
        this.Msc_Ref2_Name = Msc_Ref2_Name;
    }

    public String getMsc_Ref2_Pin_code() {
        return Msc_Ref2_Pin_code;
    }

    public void setMsc_Ref2_Pin_code(String Msc_Ref2_Pin_code) {
        this.Msc_Ref2_Pin_code = Msc_Ref2_Pin_code;
    }

    public String getMsc_Ref2_Landline_No() {
        return Msc_Ref2_Landline_No;
    }

    public void setMsc_Ref2_Landline_No(String Msc_Ref2_Landline_No) {
        this.Msc_Ref2_Landline_No = Msc_Ref2_Landline_No;
    }

    public String getMsc_Ref2_Mob_No() {
        return Msc_Ref2_Mob_No;
    }

    public void setMsc_Ref2_Mob_No(String Msc_Ref2_Mob_No) {
        this.Msc_Ref2_Mob_No = Msc_Ref2_Mob_No;
    }

    public String getDatetime_Created() {
        return Datetime_Created;
    }

    public void setDatetime_Created(String Datetime_Created) {
        this.Datetime_Created = Datetime_Created;
    }

    public String getIp_Address() {
        return Ip_Address;
    }

    public void setIp_Address(String Ip_Address) {
        this.Ip_Address = Ip_Address;
    }

    public String getUserId() {
        return UserId;
    }

    public void setUserId(String UserId) {
        this.UserId = UserId;
    }

    public String getLandlineNo_StdCode() {
        return LandlineNo_StdCode;
    }

    public void setLandlineNo_StdCode(String LandlineNo_StdCode) {
        this.LandlineNo_StdCode = LandlineNo_StdCode;
    }

    public String getPer_LandlineNo_StdCode() {
        return Per_LandlineNo_StdCode;
    }

    public void setPer_LandlineNo_StdCode(String Per_LandlineNo_StdCode) {
        this.Per_LandlineNo_StdCode = Per_LandlineNo_StdCode;
    }

    public String getOrganize_LandlineNo_StdCode() {
        return Organize_LandlineNo_StdCode;
    }

    public void setOrganize_LandlineNo_StdCode(String Organize_LandlineNo_StdCode) {
        this.Organize_LandlineNo_StdCode = Organize_LandlineNo_StdCode;
    }

    public String getMsc_Ref1_LandlineNo_StdCode() {
        return Msc_Ref1_LandlineNo_StdCode;
    }

    public void setMsc_Ref1_LandlineNo_StdCode(String Msc_Ref1_LandlineNo_StdCode) {
        this.Msc_Ref1_LandlineNo_StdCode = Msc_Ref1_LandlineNo_StdCode;
    }

    public String getMsc_Ref2_LandlineNo_StdCode() {
        return Msc_Ref2_LandlineNo_StdCode;
    }

    public void setMsc_Ref2_LandlineNo_StdCode(String Msc_Ref2_LandlineNo_StdCode) {
        this.Msc_Ref2_LandlineNo_StdCode = Msc_Ref2_LandlineNo_StdCode;
    }

    public int getBankId() {
        return BankId;
    }

    public void setBankId(int BankId) {
        this.BankId = BankId;
    }

    public int getBrokerId() {
        return BrokerId;
    }

    public void setBrokerId(int BrokerId) {
        this.BrokerId = BrokerId;
    }

    public int getIs_ApplnComplete() {
        return Is_ApplnComplete;
    }

    public void setIs_ApplnComplete(int Is_ApplnComplete) {
        this.Is_ApplnComplete = Is_ApplnComplete;
    }

    public int getProductId() {
        return ProductId;
    }

    public void setProductId(int ProductId) {
        this.ProductId = ProductId;
    }

    public int getIs_Confirm() {
        return Is_Confirm;
    }

    public void setIs_Confirm(int Is_Confirm) {
        this.Is_Confirm = Is_Confirm;
    }

    public String getTurn_Over() {
        return Turn_Over;
    }

    public void setTurn_Over(String Turn_Over) {
        this.Turn_Over = Turn_Over;
    }

    public String getDepreciation() {
        return Depreciation;
    }

    public void setDepreciation(String Depreciation) {
        this.Depreciation = Depreciation;
    }

    public String getDirector_Remuneration() {
        return Director_Remuneration;
    }

    public void setDirector_Remuneration(String Director_Remuneration) {
        this.Director_Remuneration = Director_Remuneration;
    }

    public String getProfit_Aft_Tax() {
        return Profit_Aft_Tax;
    }

    public void setProfit_Aft_Tax(String Profit_Aft_Tax) {
        this.Profit_Aft_Tax = Profit_Aft_Tax;
    }

    public String getFBA_Reg_Id() {
        return FBA_Reg_Id;
    }

    public void setFBA_Reg_Id(String FBA_Reg_Id) {
        this.FBA_Reg_Id = FBA_Reg_Id;
    }

    public String getLoan_Amount() {
        return Loan_Amount;
    }

    public void setLoan_Amount(String Loan_Amount) {
        this.Loan_Amount = Loan_Amount;
    }

    public String getROI_Id_Type() {
        return ROI_Id_Type;
    }

    public void setROI_Id_Type(String ROI_Id_Type) {
        this.ROI_Id_Type = ROI_Id_Type;
    }

    public String getProcessing_Fee() {
        return Processing_Fee;
    }

    public void setProcessing_Fee(String Processing_Fee) {
        this.Processing_Fee = Processing_Fee;
    }

    public String getLoan_Terms() {
        return Loan_Terms;
    }

    public void setLoan_Terms(String Loan_Terms) {
        this.Loan_Terms = Loan_Terms;
    }

    public String getAppln_Source() {
        return Appln_Source;
    }

    public void setAppln_Source(String Appln_Source) {
        this.Appln_Source = Appln_Source;
    }

    public String getSourcelink() {
        return sourcelink;
    }

    public void setSourcelink(String sourcelink) {
        this.sourcelink = sourcelink;
    }

    public String getCampaignName() {
        return CampaignName;
    }

    public void setCampaignName(String CampaignName) {
        this.CampaignName = CampaignName;
    }

    public String getDc_fba_reg() {
        return dc_fba_reg;
    }

    public void setDc_fba_reg(String dc_fba_reg) {
        this.dc_fba_reg = dc_fba_reg;
    }

    public String getRBA_Source() {
        return RBA_Source;
    }

    public void setRBA_Source(String RBA_Source) {
        this.RBA_Source = RBA_Source;
    }
}
