package com.rupeeboss.rba.core_loan_fm.model;

import java.util.List;

public  class LoanCityMain {
        private List<LoanCityEntity> lstCity;

        public List<LoanCityEntity> getLstCity() {
            return lstCity;
        }

        public void setLstCity(List<LoanCityEntity> lstCity) {
            this.lstCity = lstCity;
        }


    }