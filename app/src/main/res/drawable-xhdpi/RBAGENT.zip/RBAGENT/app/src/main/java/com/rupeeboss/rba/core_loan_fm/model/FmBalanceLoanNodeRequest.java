package com.rupeeboss.rba.core_loan_fm.model;

/**
 * Created by IN-RB on 23-02-2018.
 */

public class FmBalanceLoanNodeRequest {
}
