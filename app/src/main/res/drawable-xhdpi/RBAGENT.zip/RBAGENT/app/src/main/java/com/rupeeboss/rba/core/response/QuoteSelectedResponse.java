package com.rupeeboss.rba.core.response;

import com.rupeeboss.rba.core.APIResponse;

/**
 * Created by Nilesh Birhade on 03-03-2017.
 */

public class QuoteSelectedResponse extends APIResponse {
}
